%% Solve 1 dof linear/quadratic undamped, unforced, oscillator problem
clc;
close all;
clear all;
addpath('./utils','./Solvers')
rng(100);

%% Dynamical system parameters
%System parameters (Principal moments of inertia)
mass = 1;
stiff = 10;

param = [mass,stiff];
n = 2; %# state variables;

%Number of samples after trimming the ends
m = 100; %Number of samples after trimming

%Time parameters
dt = 0.001;
t0 = 0;
tf = 20;

%Intial conditions
x0 = [1;0];


% time_anim = linspace(0,100,1000);
% poinsot_construction([I1,I2,I3],w0',time_anim,1)
% 
% pause
tspanf = t0:dt:(tf-dt);

%State sapace model of a 2nd order linear differential equation
options = odeset('RelTol',1e-10,'AbsTol',1e-10*ones(1,n));
[xf] = ode5(@(t,x) SpringMassDynamics(t,x,param),tspanf,x0');
x = xf;
t = tspanf';

%Verify that the states satisfy physical constraints
Ttrue = 0.5*mass*x(:,2).^2;
Vtrue = 0.5*stiff*x(:,1).^2;
Etrue = Ttrue + Vtrue;

figure;
plot(t,Ttrue,'r');
hold on
plot(t,Vtrue,'b');
plot(t,Etrue,'k');

xlabel('Time')
legend('Kinetic energy','Potential energy','Total energy')
pause
close

%% Sample dynamical system
dsample = length(t)/m;
timeData = t(1:dsample:end);
Nsamples = length(timeData);

%% True state variables
xtrue = x(1:dsample:end,1:2);

%% True state derivatives
dxtrue = zeros(Nsamples,2);
for k = 1:Nsamples
dxtrue(k,:) = [xtrue(k,2); -stiff/mass*xtrue(k,1)];
end

%% Add noise to the states
eta = 0.05;
etadx = 0.05;
xnoisy = xtrue + eta*randn(Nsamples,n);
dxnoisy = dxtrue + etadx*randn(Nsamples,n);

xDataT = [xnoisy];
dxDataT = [dxtrue];

%Total energy (conserved)
Tnoisy = 0.5*mass*xnoisy(:,2).^2;
Vnoisy = 0.5*stiff*xnoisy(:,1).^2;
Enoisy = Tnoisy + Vnoisy;

figure;
plot(timeData,Tnoisy,'r.-');
hold on;
plot(timeData,Vnoisy,'b.-');
plot(timeData,Enoisy,'k.');
plot(timeData,Etrue(1)*ones(Nsamples,1),'g');
legend('Kinetic energy','Potential energy','Total energy')
xlabel('Time')
pause
close

figure(1);
subplot(2,1,1);
plot(timeData, xDataT(:,1),'r.')
xlabel('Time')
ylabel('x_1(t)')

subplot(2,1,2);
plot(timeData, xDataT(:,2),'r.')
xlabel('Time')
ylabel('x_2(t)')

pause
close all

figure(2);
subplot(2,1,1);
plot(timeData, dxDataT(:,1),'r.')
xlabel('Time')
ylabel('dx_1(t)')

subplot(2,1,2);
plot(timeData, dxDataT(:,2),'r.')
xlabel('Time')
ylabel('dx_2(t)')

pause
close all

%% Original basis
p = 2;%polynomial order 
Nb = nchoosek(p+n,n);
index_pc = nD_polynomial_array(n,p);

% True coefficient vector in monomial basis
XiT = zeros(Nb,n);

XiT(3,1) = 1;
XiT(2,2) = -stiff/mass;

C = zeros(Nsamples,Nb);
for isim = 1:Nsamples
    crow = piset_monomial(xDataT(isim,:),index_pc);
    C(isim,:) = crow(1:Nb);
end

%Normalize columns
Ccol_norm = (sqrt(sum(C.*C,1)))';
Wn = diag(1./Ccol_norm); %Normalization matrix 
Cn = C * Wn; %Column-normalized basis matrix

CorrM = Cn'*Cn;

figure;
imagesc(CorrM);
title('Correlation matrix')
colormap(jet);
colorbar;

cond(C)
cond(Cn)

[U,S,V] = svd(C);
maxrnk = 5;

figure;
subplot(1,2,1)
semilogy(diag(S),'ro','MarkerFaceColor',[1,0,0]);
% hold on
% semilogy([0 Nb],[tol tol],'k');
title('Singular values of C');
axis('square')

%ix gives the column number of all independent columns of the matrix Cn
%Each column of the matrix P gives the linear dependencies of the columns
%of Cn in terms of the independent columns given in ix

[P,ix,k] = matrixIDvR(Cn,maxrnk);

norm(Cn(:,ix)*P-Cn)/norm(Cn)

LD = zeros(Nb);
LD(ix,:) = P;
LD

subplot(1,2,2)
imagesc(LD);
title('Linear dependence matrix')
colormap(jet);
colorbar;
axis('square')
pause
close

%% Solve noisless case using least squares in a polynomial basis of order p with n states
Xi_LS = C\dxDataT;

%Xi_LS(abs(Xi_LS) < 0.0001) = 0 %Treshold small coefficients due to numerical errors (make sure that the true coefficients exceed the treshold value)
Xi_LS
pause

%% Solve noisless case using BPDN in a polynomial basis of order p with n states
lambda = eps;
Xi_BPDN = zeros(Nb,n);

for d = 1:n

b = dxDataT(:,d);
y_BPDN = SolveBP(Cn,b,Nb,100000,lambda,1e-11);
Xi_BPDN(:,d) = Wn*y_BPDN;

end

%Xi_BPDN(abs(Xi_BPDN) < 0.0001) = 0 %Treshold small coefficients due to numerical errors (make sure that the true coefficients exceed the treshold value)
Xi_BPDN
pause

%% Compute residuals %%

res_LS = C*Xi_LS - dxDataT;

resw1_LS = rms(res_LS(:,1));
resw2_LS = rms(res_LS(:,2));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

res_BPDN = C*Xi_BPDN - dxDataT;

resw1_BPDN = rms(res_BPDN(:,1));
resw2_BPDN = rms(res_BPDN(:,2));

%% Prediction %%

tini = 0;
dt = 0.001;
tend = 100;
tpred = tini:dt:tend;

% Exact trajectory
options = odeset('RelTol',1e-10,'AbsTol',1e-10*ones(1,n));
[t_exact, x_exact] = ode45(@(t,x) SpringMassDynamics(t,x,param),tpred,x0',options);

% LS trajectory
[t_LS, x_LS] = ode45(@(t,x) predictDynamics(t,x,Xi_LS,p),tpred,x0',options);

% BPDN trajectory
[t_BPDN, x_BPDN] = ode45(@(t,x) predictDynamics(t,x,Xi_BPDN,p),tpred,x0',options);


figure;
suptitle('LS')
subplot(2,1,1);
plot(t_exact,x_exact(:,1),'g');
hold on
plot(t_LS,x_LS(:,1),'r--');
xlabel('Time')
ylabel('x_1(t)')

subplot(2,1,2);
plot(t_exact,x_exact(:,2),'g');
hold on
plot(t_LS,x_LS(:,2),'r--');
xlabel('Time')
ylabel('x_2(t)')


figure;
suptitle('BPDN')
subplot(2,1,1);
plot(t_exact,x_exact(:,1),'g');
hold on
plot(t_BPDN,x_BPDN(:,1),'r--');
xlabel('Time')
ylabel('x_1(t)')

subplot(2,1,2);
plot(t_exact,x_exact(:,2),'g');
hold on
plot(t_BPDN,x_BPDN(:,2),'r--');
xlabel('Time')
ylabel('x_2(t)')

%Compute rmse between exact and identified trajectories

%% LS

etraj_LS = x_LS - x_exact;

RMSEw1_LS = rms(etraj_LS(:,1))
RMSEw2_LS = rms(etraj_LS(:,2))

%% BPDN

etraj_BPDN = x_BPDN - x_exact;

RMSEw1_BPDN = rms(etraj_BPDN(:,1))
RMSEw2_BPDN = rms(etraj_BPDN(:,2))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Modified basis
remove_basis = [1];
index_basis = 1:Nb;
CM = C; CM(:,remove_basis) = [];
index_pcM = index_pc;
index_basis(remove_basis) = [];
index_pcM(remove_basis,:) = [];
NbM = size(CM,2);

%Normalize columns
Ccol_normM = (sqrt(sum(CM.*CM,1)))';
WnM = diag(1./Ccol_normM); %Normalization matrix 
CnM = CM * WnM; %Column-normalized basis matrix

CorrMM = CnM'*CnM;

figure;
imagesc(CorrMM);
title('Correlation matrix')
colormap(jet);
colorbar;

cond(CM)
cond(CnM)

[UM,SM,VM] = svd(CM);

figure;
subplot(1,2,1)
semilogy(diag(SM),'ro','MarkerFaceColor',[1,0,0]);
title('Singular values of C');
axis('square')

%ix gives the column number of all independent columns of the matrix Cn
%Each column of the matrix P gives the linear dependencies of the columns
%of Cn in terms of the independent columns given in ix
[PM,ixM,kM] = matrixIDvR(CnM,maxrnk)
% index_pcM = index_pcM(ixM,:);
norm(CnM(:,ixM)*PM-CnM)/norm(CnM)

LDM = zeros(NbM);
LDM(ixM,:) = PM;

subplot(1,2,2)
imagesc(LDM);
title('Linear dependence matrix')
colormap(jet);
colorbar;
axis('square')
pause
close

%% Solve noisless case using least squares in a polynomial basis of order p with n states
Xi_LSM1 = CM\dxDataT;
Xi_LSM = zeros(Nb,n);
Xi_LSM(index_basis,:) = Xi_LSM1;


%Xi_LS(abs(Xi_LS) < 0.0001) = 0 %Treshold small coefficients due to numerical errors (make sure that the true coefficients exceed the treshold value)
Xi_LSM
pause

%% Solve noisless case using BPDN in a polynomial basis of order p with n states
lambda = eps;
Xi_BPDNM1 = zeros(NbM,n);

for d = 1:n

b = dxDataT(:,d);
y_BPDNM = SolveBP(CnM,b,NbM,100000,lambda,1e-11);
Xi_BPDNM1(:,d) = WnM*y_BPDNM;

end
Xi_BPDNM(index_basis,:) = Xi_BPDNM1;

%Xi_BPDN(abs(Xi_BPDN) < 0.0001) = 0 %Treshold small coefficients due to numerical errors (make sure that the true coefficients exceed the treshold value)
Xi_BPDNM
pause

%% Compute residuals %%

res_LSM = C*Xi_LSM - dxDataT;

resw1_LSM = rms(res_LSM(:,1));
resw2_LSM = rms(res_LSM(:,2));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

res_BPDNM = C*Xi_BPDNM - dxDataT;

resw1_BPDNM = rms(res_BPDNM(:,1));
resw2_BPDNM = rms(res_BPDNM(:,2));

%% Prediction %%

tini = 0;
dt = 0.001;
tend = 100;
tpred = tini:dt:tend;

% Exact trajectory
options = odeset('RelTol',1e-10,'AbsTol',1e-10*ones(1,n));
[t_exact, x_exact] = ode45(@(t,x) SpringMassDynamics(t,x,param),tpred,x0',options);

% LS trajectory
[t_LSM, x_LSM] = ode45(@(t,x) predictDynamicsM(t,x,Xi_LSM,index_pc),tpred,x0',options);

% BPDN trajectory
[t_BPDNM, x_BPDNM] = ode45(@(t,x) predictDynamicsM(t,x,Xi_BPDNM,index_pc),tpred,x0',options);


figure;
suptitle('LSM')
subplot(2,1,1);
plot(t_exact,x_exact(:,1),'g');
hold on
plot(t_LSM,x_LSM(:,1),'r--');
xlabel('Time')
ylabel('x_1(t)')

subplot(2,1,2);
plot(t_exact,x_exact(:,2),'g');
hold on
plot(t_LSM,x_LSM(:,2),'r--');
xlabel('Time')
ylabel('x_2(t)')


figure;
suptitle('BPDNM')
subplot(2,1,1);
plot(t_exact,x_exact(:,1),'g');
hold on
plot(t_BPDNM,x_BPDNM(:,1),'r--');
xlabel('Time')
ylabel('x_1(t)')

subplot(2,1,2);
plot(t_exact,x_exact(:,2),'g');
hold on
plot(t_BPDNM,x_BPDNM(:,2),'r--');
xlabel('Time')
ylabel('x_2(t)')

%Compute rmse between exact and identified trajectories

%% LS

etraj_LSM = x_LSM - x_exact;

RMSEw1_LSM = rms(etraj_LSM(:,1))
RMSEw2_LSM = rms(etraj_LSM(:,2))

%% BPDN

etraj_BPDNM = x_BPDNM - x_exact;

RMSEw1_BPDNM = rms(etraj_BPDNM(:,1))
RMSEw2_BPDNM = rms(etraj_BPDNM(:,2))

for d = 1:n
solerr_LS(d) = norm(Xi_LS(:,d) - XiT(:,d))/norm(XiT(:,d));
solerr_LSM(d) = norm(Xi_LSM(:,d) - XiT(:,d))/norm(XiT(:,d));

solerr_BPDN(d) = norm(Xi_BPDN(:,d) - XiT(:,d))/norm(XiT(:,d));

solerr_BPDNM(d) = norm(Xi_BPDNM(:,d) - XiT(:,d))/norm(XiT(:,d));
end


solerr_LS
solerr_LSM
solerr_BPDN
solerr_BPDNM
