%% Solve 1 dof linear/quadratic undamped, unforced, oscillator problem
clc;
close all;
clear all;
addpath('./regtools','./utils')
rng(100);

%% Dynamical system parameters
%System parameters (Principal moments of inertia)
mass = 1;
stiff = 10;

param = [mass,stiff];
n = 2; %# state variables;

%Number of samples after trimming the ends
trimratio = 0.1;%trimming ratio
sampleTime = 0.01; %Sampling time
m = 200; %Number of samples after trimming

%Time parameters
dt = 0.001;
t0 = 0;
tf = t0 + m*sampleTime/(1-trimratio);

%Intial conditions
x0 = [1,0];

tspanf = t0:dt:(tf-dt);

%State sapace model of a 2nd order linear differential equation
options = odeset('RelTol',1e-10,'AbsTol',1e-10*ones(1,n));
[xf] = ode5(@(t,x) SpringMassDynamics(t,x,param),tspanf,x0');
x = xf;
t = tspanf';

%% Sample dynamical system
dsample = sampleTime/dt;
timeData = t(1:dsample:end);
Nsamples = length(timeData);

trimlow = round(trimratio/2*Nsamples);
trimupp = round((1-trimratio/2)*Nsamples);
trim = trimlow:trimupp;

%% True state variables
xtrue = x(1:dsample:end,:);
xDataT = xtrue;

%% True state derivatives
dxtrue = zeros(Nsamples,2);
for k = 1:Nsamples
    dxtrue(k,:) = [xtrue(k,2),-stiff/mass*xtrue(k,1)];
end

dxDataT = dxtrue;

figure(1);
subplot(2,1,1);
plot(timeData, xDataT(:,1),'k')
xlabel('Time')
ylabel('x_1(t)')

subplot(2,1,2);
plot(timeData, xDataT(:,2),'k')
xlabel('Time')
ylabel('x_2(t)')

pause
close all

figure(2);
subplot(2,1,1);
plot(timeData, dxDataT(:,1),'k')
xlabel('Time')
ylabel('dx_1(t)')

subplot(2,1,2);
plot(timeData, dxDataT(:,2),'k')
xlabel('Time')
ylabel('dx_2(t)')

pause
close all

%Build dictionary for the entire data set
p = 1;
Nb = nchoosek(p+n,n);
index_pc = nD_polynomial_array(n,p)

C = zeros(Nsamples,Nb);
for isim = 1:Nsamples
    crow = piset_monomial(xDataT(isim,:),index_pc);
    C(isim,:) = crow(1:Nb);
end

XiT = C\dxDataT;
XiT(abs(XiT) < 0.001) = 0
pause


%% Noisy state derivatives
dxDataN = zeros(Nsamples,n);

%% NOISE MODELS

% SNR = 1000;%SNR is defined as (sqrt(1/N*sum_k(sk^2))/sigma_noise)^2 in terms of power
% sigma1 = sqrt(rms(x1true)^2/SNR);
% sigma2 = sqrt(rms(x2true)^2/SNR);
% sigma3 = sqrt(rms(x3true)^2/SNR);

sigmas = logspace(-6,-1,6);
Nsigmas = length(sigmas);
SNR1 = zeros(1,Nsigmas);
SNR2 = zeros(1,Nsigmas);


% SNR = [1e5,1e4,1e3,1e2,1e1,1];
% SNR = logspace(8,2,7);
% % SNR = 100;
% 
% Nsigmas = length(SNR);
% sigma1 = zeros(1,Nsigmas);
% sigma2 = zeros(1,Nsigmas);
% sigma3 = zeros(1,Nsigmas);


errorx_sig = zeros(Nsigmas,n);
errordx_sig = zeros(Nsigmas,n);
amplifdx_sig = zeros(Nsigmas,n);

lambda_min = eps;
lambda_max = 100;
lambdasLc = nlogspace(log(lambda_min),log(lambda_max),200);
Nlamb = length(lambdasLc);

errordxLcnoise = zeros(Nsigmas,n,Nlamb);
residualLcnoise = zeros(Nsigmas,n,Nlamb);
regularizerLcnoise = zeros(Nsigmas,n,Nlamb);

resCorner = zeros(Nsigmas, n);
regCorner = zeros(Nsigmas, n);


for j = 1:Nsigmas

%     sigma1(j) = sqrt(rms(x1true)^2/SNR(j));
%     sigma2(j) = sqrt(rms(x2true)^2/SNR(j));
%     sigma3(j) = sqrt(rms(x3true)^2/SNR(j));

    sigma1 = sigmas(j);
    sigma2 = sigmas(j);
%     
    SNR1(j) = (rms(xtrue(:,1))/sigma1)^2;
    SNR2(j) = (rms(xtrue(:,2))/sigma2)^2;
    
% X1 state
xnoisy(:,1) = xtrue(:,1) + sigma1*randn(Nsamples,1);
% X2 state
xnoisy(:,2) = xtrue(:,2) + sigma2*randn(Nsamples,1);

xDataN = xnoisy;

% figure(1);
% subplot(2,1,1);
% plot(timeData, xDataN(:,1),'r.')
% hold on
% plot(timeData, xDataT(:,1),'k')
% xlabel('Time')
% ylabel('x_1(t)')
% legend('Noisy','True')
% 
% subplot(2,1,2);
% plot(timeData, xDataN(:,2),'r.')
% hold on
% plot(timeData, xDataT(:,2),'k')
% xlabel('Time')
% ylabel('x_2(t)')
% legend('Noisy','True')
% 
% pause
% close all

errorxsn(1) = norm(xnoisy(:,1) - xtrue(:,1))/norm(xtrue(:,1));
errorxsn(2) = norm(xnoisy(:,2) - xtrue(:,2))/norm(xtrue(:,2));

errorxs(1) = norm(xnoisy(:,1) - xtrue(:,1));
errorxs(2) = norm(xnoisy(:,2) - xtrue(:,2));

%% NUMERICAL DIFFERENTIATION

%%  Tikhonov regularization   
    epsilon = 0.01; % Corner point stopping criterion
    itr2_max = 50; % Maximum iterations to find the corner point
    pGS = (1+sqrt(5))/2; %Golden search parameter

    %Vector of ordinates
    tvec = timeData;
    tvecm = 0.5*(tvec(1:end-1) + tvec(2:end));
    
    errordxsn = zeros(1,n);
    errordxs = zeros(1,n);

    errordxLc = zeros(Nlamb,1);
    residualLc = zeros(Nlamb,1);
    regularizerLc = zeros(Nlamb,1);
    

for d = 1:n
    
    fprintf(['State: ', num2str(d),'\n'])
    
    b = xDataN(:,d);
    
    itr2 = 1;
    lambdas = [lambda_min,lambda_max,0,0];
    gap = 1;
    
    residual = zeros(1,4);
    regularizer = zeros(1,4);
    errordx = zeros(1,4);
    xis = zeros(1,4);
    etas = zeros(1,4);    
    
    %% Generate full Lcurve
    
    for l = 1:Nlamb
        l
        b = xDataN(:,d);
        lambda  = lambdasLc(l);
        [dxm,A,L,res,relres,normreg] = tik_diff_uniform(tvec,b,lambda);
        tdx = 0.5*(tvec(1:end-1) + tvec(2:end)); %Derivatives computed at the midpoints of t

        dx = pchip(tdx,dxm,tvec);%Interpolation to the grid points
        
        errordxLc(l) = norm(dxDataT(:,d) - dx)/norm(dx);
        residualLc(l) = res;
        regularizerLc(l) = normreg;
        
        errordxLcnoise(j,d,l) = errordxLc(l);
        residualLcnoise(j,d,l) = residualLc(l);
        regularizerLcnoise(j,d,l) = regularizerLc(l);
        
        
    end
    
%     figLcurve = figure(1);
%     axLcurve = axes('Parent',figLcurve);
%     LcurvePlot = plot(axLcurve,log(residualLc),log(regularizerLc),'r.-');
%     ylabel('\eta = log(||Dx||_2)')
%     xlabel('\xi = log(||Ax - b||_2)')
%     grid on   
%     pause
%     indmin = find(errordxLc == min(errordxLc));
%     hold on
%     plot(axLcurve,log(residualLc(indmin)),log(regularizerLc(indmin)),'Color','g','Marker','.','MarkerSize',20)
%     drawnow
%      
%     figError = figure(2);
%     axError = axes('Parent',figError);
%     ErrorPlot = loglog(axError,lambdasLc,errordxLc,'r.-');
%     ylabel('log(||x - x^*||_2 / ||x^*||_2)')
%     xlabel('\lambda')
%     grid on
%     hold on
%     pause
    
    while (gap > epsilon || itr2 < itr2_max)
        
    % Solve BPDN for extremals lambda_min and lambda_max
    if itr2 == 1
        for s = 1:2 %Regularization parameter
        
            lambda = lambdas(s);
            fprintf(['Current lambda: ',num2str(lambda),'\n'])
        
            %Solve Tikhonov regularization problem
            [dxm,A,L,res,relres,normreg] = tik_diff_uniform(tvec,b,lambda);
             tdx = 0.5*(tvec(1:end-1) + tvec(2:end)); %Derivatives computed at the midpoints of t
             dx = pchip(tdx,dxm,tvec);%Interpolation to the grid points
             errordx(s) = norm(dxDataT(:,d) - dx)/norm(dxDataT(:,d));
             %Compute l2-norm of residual and l2-norm of weighted solution
             residual(s) = res;
             regularizer(s) = normreg;

             xis(s) = log(residual(s));
             etas(s) = log(regularizer(s));
        
        end

    lambdas(3) = exp((log(lambdas(2)) + pGS*log(lambdas(1)))/(1+pGS));%Store lambda 2
    lambdas(4) = exp(log(lambdas(1)) + log(lambdas(2)) - log(lambdas(3)));%Store lambda 3
    
    %Solve BPDN for intermediate lambdas 2,3
        for s = 3:4 %Regularization parameter
        
            lambda = lambdas(s);
            fprintf(['Current lambda: ',num2str(lambda),'\n'])
        
            %Solve Tikhonov regularization problem
            [dxm,A,L,res,relres,normreg] = tik_diff_uniform(tvec,b,lambda);
            tdx = 0.5*(tvec(1:end-1) + tvec(2:end)); %Derivatives computed at the midpoints of t
             dx = pchip(tdx,dxm,tvec);%Interpolation to the grid points
             %Compute relative error in the derivative
             errordx(s) = norm(dxDataT(:,d) - dx)/norm(dxDataT(:,d));
             %Compute l2-norm of residual and l2-norm of weighted solution
             residual(s) = res;
             regularizer(s) = normreg;

             xis(s) = log(residual(s));
             etas(s) = log(regularizer(s));
        
        end
    
            %Sort points (xi,eta) corresponding to each lambda in ascending order

            P = [xis(1),xis(2),xis(3),xis(4);etas(1),etas(2),etas(3),etas(4)];

            [lambdas, indx] = sort(lambdas);

            P = P(:,indx);%Sort points according to values of lambda in ascending order
       
     end%End of loop for the first iteration
    
    %% Compute curvatures
    
    %Compute coordimates of the 4 current points
    C2 = menger2(P(:,1),P(:,2),P(:,3));
    C3 = menger2(P(:,2),P(:,3),P(:,4));

    while C3 < 0 %Check if the curvature is negative and update values
        
         %Reassign maximum and interior lambdas and Lcurve points (Golden search interval)
         lambdas(4) = lambdas(3);
         P(:,4) = P(:,3);
         lambdas(3) = lambdas(2);
         P(:,3) = P(:,2);
        
         %Update interior lambda and interior point
         lambdas(2) = exp((log(lambdas(4)) + pGS*log(lambdas(1)))/(1+pGS));
        
         %Solve Tikhonov regularization problem for lambda2
         [dxm,A,L,res,relres,normreg] = tik_diff_uniform(tvec,b,lambdas(2));
         tdx = 0.5*(tvec(1:end-1) + tvec(2:end)); %Derivatives computed at the midpoints of t
         dx = pchip(tdx,dxm,tvec);%Interpolation to the grid points
        
         %Compute relative error in the derivative
         errordx = norm(dxDataT(:,d) - dx)/norm(dxDataT(:,d));
         %Compute l2-norm of residual and l2-norm of weighted solution
         residual = res;
         regularizer = normreg;

         xi = log(residual);
         eta = log(regularizer);
        
         P(:,2) = [xi;eta];
         C3 = menger2(P(:,2),P(:,3),P(:,4));
        
    end
    
    if C2 > C3 %Update values depending on the curvature at the new points
        
        display('Curvature C2 is greater than C3');
        lambdaC = lambdas(2);
        
        %Reassign maximum and interior lambdas and Lcurve points (Golden search interval)
        lambdas(4) = lambdas(3);
        P(:,4) = P(:,3);
        
        lambdas(3) = lambdas(2);
        P(:,3) = P(:,2);
        
        %Update interior lambda and interior point
        lambdas(2) = exp((log(lambdas(4)) + pGS*log(lambdas(1)))/(1+pGS));
        
        %Solve Tikhonov regularization problem for lambda2
         [dxm,A,L,res,relres,normreg] = tik_diff_uniform(tvec,b,lambdas(2));
         tdx = 0.5*(tvec(1:end-1) + tvec(2:end)); %Derivatives computed at the midpoints of t
         dx = pchip(tdx,dxm,tvec);%Interpolation to the grid points
        
         %Compute relative error in the derivative
         errordx = norm(dxDataT(:,d) - dx)/norm(dxDataT(:,d));
         %Compute l2-norm of residual and l2-norm of weighted solution
         residual = res;
         regularizer = normreg;

         xi = log(residual);
         eta = log(regularizer);
        
         P(:,2) = [xi;eta];

%          plot(axLcurve,xi,eta,'Color','k','Marker','o','MarkerSize',5,'LineStyle','none')
%          drawnow
%          plot(axError,lambdas(2),errordx,'Color','k','Marker','o','MarkerSize',5,'LineStyle','none')
%          drawnow
    else
        
        display('Curvature C3 is greater than C2');
        lambdaC = lambdas(3);
        
        %Reassign maximum and interior lambdas and Lcurve points (Golden search interval)
        lambdas(1) = lambdas(2);
        P(:,1) = P(:,2);
        
        lambdas(2) = lambdas(3);
        P(:,2) = P(:,3);
        
        %Update interior lambda and interior point
        lambdas(3) = exp(log(lambdas(1)) + log(lambdas(4)) - log(lambdas(2)));
        
        %Solve Tikhonov regularization problem for lambda3
         [dxm,A,L,res,relres,normreg] = tik_diff_uniform(tvec,b,lambdas(3));
         tdx = 0.5*(tvec(1:end-1) + tvec(2:end)); %Derivatives computed at the midpoints of t
         dx = pchip(tdx,dxm,tvec);%Interpolation to the grid points
        
         %Compute relative error in the derivative
         errordx = norm(dxDataT(:,d) - dx)/norm(dxDataT(:,d));
         %Compute l2-norm of residual and l2-norm of weighted solution
         residual = res;
         regularizer = normreg;

         xi = log(residual);
         eta = log(regularizer);
        
         P(:,3) = [xi;eta];

%          plot(axLcurve,xi,eta,'Color','k','Marker','o','MarkerSize',5,'LineStyle','none')
%          drawnow
%          plot(axError,lambdas(3),errordx,'Color','k','Marker','o','MarkerSize',5,'LineStyle','none')
%          drawnow
        
    end
    
    %Compute relative gap
    gap = (lambdas(4) - lambdas(1))/lambdas(4);
    lambda_itr2(itr2) = lambdaC;
    itr2 = itr2 + 1;    
    
    end
     
    %% Pick the corner
    lambda_corner = lambdaC;
    display(['Optimal lambda: ',num2str(lambda_corner)])

        
        %Solve Tikhonov regularization problem for optimal lambda
         [dxm,A,L,res,relres,normreg] = tik_diff_uniform(tvec,b,lambda_corner);
         resCorner(j,d) = res;
         regCorner(j,d) = normreg;
         tdx = 0.5*(tvec(1:end-1) + tvec(2:end)); %Derivatives computed at the midpoints of t
         dx = pchip(tdx,dxm,tvec);%Interpolation to the grid points
         dxDataN(:,d) = dx';
         errordxsn(d) = norm(dxDataT(:,d) - dx)/norm(dxDataT(:,d));
         errordxs(d) = norm(dxDataT(:,d) - dx);
         
%          figure;
%          plot(timeData, dxDataN(:,d),'r.')
%          hold on
%          plot(timeData, dxDataT(:,d),'k')
%          xlabel('Time')
%          ylabel('dx(t)')
%          legend('True','Noisy')
%          pause
        
         display(['Derivative error for state ',num2str(d),' = ',num2str(errordxs(d))])
%          lambda_corner
%          pause
%          close all
end

display(['Error in states: ',num2str(errorxsn)])
display(['Error in derivatives: ',num2str(errordxsn)])
display(['Error amplification: ',num2str(errordxs./errorxs)])
% pause
% close

errorx_sig(j,:) = errorxsn
errordx_sig(j,:) = errordxsn
amplifdx_sig(j,:) = errordxs./errorxs

SpringMassData(j).xtrue = xDataT(trim,:);
SpringMassData(j).dxtrue = dxDataT(trim,:);
SpringMassData(j).xnoisy = xDataN(trim,:);
SpringMassData(j).dxnoisy = dxDataN(trim,:);
SpringMassData(j).time = timeData(trim);
SpringMassData(j).sigma = sigmas;
SpringMassData(j).SNR = [SNR1(j), SNR2(j)];
SpringMassData(j).paramsLabel = ['mass, stiff'];
SpringMassData(j).paramsValue = [mass,stiff];

% pause

end

save('SpringMassTikhonovNumDiff200','errordxLcnoise','residualLcnoise','regularizerLcnoise','resCorner','regCorner','SpringMassData')

%Fixed sigma plots
figure(1)
% plot(sigmas,errorx_sig(:,1),'r','Interpreter','latex')
loglog(sigmas,errorx_sig(:,1),'r-o')
hold on
loglog(sigmas,errorx_sig(:,2),'g-x')
xlabel('Noise level \sigma')
ylabel('\frac{\|x - x^{*}\|_2}{\|x^{*}\|_2}')
grid on
legend('State x_1','State x_2')

figure(2)
loglog(sigmas,errordx_sig(:,1),'r-o')
hold on
loglog(sigmas,errordx_sig(:,2),'g-x')
xlabel('Noise level \sigma')
ylabel('\frac{\|\dot{x} - \dot{x}^{*}\|_2}{\|\dot{x}^{*}\|_2}')
grid on
legend('State x_1','State x_2')

figure(3)
semilogx(sigmas,amplifdx_sig(:,1),'r-o')
hold on
semilogx(sigmas,amplifdx_sig(:,2),'g-x')
xlabel('Noise level \sigma')
ylabel('Error amplification')
grid on
legend('State x_1','State x_2')

figure(4)
plot(sigmas,resCorner(:,1),'r-o')
hold on
plot(sigmas,resCorner(:,2),'g-x')
xlabel('Noise level \sigma')
ylabel('Residual')
grid on
legend('State x_1','State x_2')




