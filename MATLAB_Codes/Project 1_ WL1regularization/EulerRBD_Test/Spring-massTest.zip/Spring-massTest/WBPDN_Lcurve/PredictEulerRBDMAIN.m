%% Identification of the Euler RB Dynamics
close all;
clear all;
addpath('./utils','./Data')

%%%%% WL1min identified model at iteration 0 %%%%% 
% load('Xi_it0_Lorenz63')
% XiI = Xi_it0;

%%%%% WL1min identified model at iteration 5 %%%%% 
% load('Xi_noise_EulerRBD')
load('XiT_Euler')

% XiI = Xi_noise(:,:,6);
XiI = XiT;

%System parameters
I1 = 1;
I2 = 2;
I3 = 3;
alpha = 0;
param = [I1,I2,I3,alpha];

n = 7; %# state variables;
plyord = 3;
usesine = 0;

%Time parameters
dt = 0.0001; %Time step
t0 = 0; %Initial time
tf = 30; %Final time

%Intial conditions
q0 = [0;0;0;1];
w0 = [1;0;0.5];
x0 = [w0;q0];

%Time span
tspan = t0:dt:tf;

%% Generate true model
options = odeset('RelTol',1e-12,'AbsTol',1e-12*ones(1,n));
[tT, xT] = ode45(@(t,x) EulerRBD(t,x,param),tspan,x0,options);

%% Generate identified model
[tI, xI] = ode45(@(t,x)predictEulerRBD(t,x,XiI,plyord),tspan,x0,options);

%% Plot data (true vs identified states)
figure(1);
suptitle('Exact vs predicted EulerRBD states')
subplot(3,1,1)
plot(tT,xT(:,1),'g-',tI,xI(:,1),'k-')
xlabel('Time');
ylabel('\omega_1(t)');
grid on
legend('Exact x','Predicted x')

subplot(3,1,2)
plot(tT,xT(:,2),'g-',tI,xI(:,2),'k-')
xlabel('Time');
ylabel('\omega_2(t)');
grid on
legend('Exact y','Predicted y')

subplot(3,1,3)
plot(tT,xT(:,3),'g-',tI,xI(:,3),'k-')
xlabel('Time');
ylabel('\omega_3(t)');
grid on
legend('Exact y','Predicted y')

figure(2);
suptitle('Exact vs predicted EulerRBD states')
subplot(4,1,1)
plot(tT,xT(:,4),'g-',tI,xI(:,4),'k-')
xlabel('Time');
ylabel('q_1(t)');
grid on
legend('Exact x','Predicted x')

subplot(4,1,2)
plot(tT,xT(:,5),'g-',tI,xI(:,5),'k-')
xlabel('Time');
ylabel('q_2(t)');
grid on
legend('Exact y','Predicted y')

subplot(4,1,3)
plot(tT,xT(:,6),'g-',tI,xI(:,6),'k-')
xlabel('Time');
ylabel('q_3(t)');
grid on
legend('Exact y','Predicted y')

subplot(4,1,4)
plot(tT,xT(:,7),'g-',tI,xI(:,7),'k-')
xlabel('Time');
ylabel('q_0(t)');
grid on
legend('Exact y','Predicted y')

% %% Plot data (true vs identified states)
% figure(2);
% suptitle('Exact vs predicted Duffing models')
% plot(xT(:,1),xT(:,2),'g-')
% hold on
% plot(xI(:,1),xI(:,2),'k-')
% grid on
% axis('equal')
% xlabel('x(t)');
% ylabel('y(t)');
% legend('Exact model','Identified model')

save('PredictedLorenz63Data','xT','xI','tT')
