%% SPARSE IDENTIFICATION OF NONLINEAR DYNAMICAL SYSTEMS
clear all, close all, clc
addpath('./Solvers','./utils');

%% Load data
load('SpringMassTikhonovNumDiff200');

% Order of expansion
p = 3;
Nsamp_total = 200;
% num_itr = 5;
num_itr = 3;
Ndofs = 2;

%Noise levels
Nsigmas = length(SpringMassData);
sigmas = SpringMassData(1).sigma;
% True coefficient vector in monomial basis
Nb = nchoosek(p+Ndofs,Ndofs);
mass = SpringMassData(1).paramsValue(1);
stiff = SpringMassData(1).paramsValue(2);

% Nsigmas = 1;
%Preallocate variables
tr_errLc_noise = zeros(Nsigmas,Ndofs,num_itr+1,200);
sol_errLc_noise = zeros(Nsigmas,Ndofs,num_itr+1,200);
sol_l1_normLc_noise = zeros(Nsigmas,Ndofs,num_itr+1,200);

sol_l1_normCorner = zeros(Nsigmas,Ndofs,num_itr+1);
tr_errsCorner = zeros(Nsigmas,Ndofs,num_itr+1);

Xi_noise = zeros(Nsigmas,Ndofs,Nb);
LD_noise = zeros(Nsigmas,Nb,Nb);

for j = 1:Nsigmas

%Gather data

%True data
xDataT = SpringMassData(j).xtrue(1:Nsamp_total,:);
dxDataT = SpringMassData(j).dxtrue(1:Nsamp_total,:);
tDataT = SpringMassData(j).time(1:Nsamp_total,1);
dtDataT = mean(tDataT(2:end) - tDataT(1:end-1));

%Noisy data
xData = SpringMassData(j).xnoisy(1:Nsamp_total,:);
dxData = SpringMassData(j).dxnoisy(1:Nsamp_total,:);


% Setup the basis
index_pc = nD_polynomial_array(Ndofs,p);
Nb = size(index_pc,1);

%Allocate identified coefficients
Xi = zeros(Nb,Ndofs);

%% START L-Curve

%Define sigma and p ranges to loop over
%Define sigmas min sigma*|x|_1 + |Ax - b|_2 

lambda_itr = zeros(num_itr+1);
epsilon = 0.01; % Corner point stopping criterion
itr2_max = 20; % Maximum iterations to find the corner point
pGS = (1+sqrt(5))/2; %Golden search parameter

%Define penalization parameter (exponents of the weighting matrix) 
q = 2;
eps_w = 0.0001;
coefferr = zeros(num_itr+1,1);% NOTE: the first row represents the solution error at 0th iteration

%Build dictionary for the entire data set
C = zeros(Nsamp_total,Nb);
for isim = 1:Nsamp_total
    crow = piset_monomial(xData(isim,:),index_pc);
    C(isim,:) = crow(1:Nb);
end

%Normalize columns
Ccol_norm = (sqrt(sum(C.*C,1)))';
Wn = diag(1./Ccol_norm); %Normalization matrix 
Cn = C * Wn; %Column-normalized basis matrix

cond(C)
cond(Cn)

[U,S,V] = svd(C);

figure;
subplot(1,2,1)
semilogy(diag(S),'ro','MarkerFaceColor',[1,0,0]);
% hold on
% semilogy([0 Nb],[tol tol],'k');
title('Singular values of C');
axis('square')

%ix gives the column number of all independent columns of the matrix Cn
%Each column of the matrix P gives the linear dependencies of the columns
%of Cn in terms of the independent columns given in ix
% maxrankM = input('Please, select the rank of C: ')
maxrankM = 7;
[P,ix,k] = matrixIDvR(Cn,maxrankM);
norm(Cn(:,ix)*P-Cn)/norm(Cn)

LDn = zeros(Nb);
LDn(ix,:) = P;
LD_noise(j,:,:) = LDn.*((1./Ccol_norm)*Ccol_norm');

subplot(1,2,2)
imagesc(LDn);
title('Linear dependence matrix')
colormap(jet);
colorbar;
axis('square')
%% Modify the bais matrix
remove_basis = [6,8,9];
CM = C;
CM(:,remove_basis) = [];
Nbasis = size(CM,2);
index_basis = 1:Nb;
index_basis(remove_basis) = [];
index_pcM = index_pc;
index_pcM(remove_basis,:) = [];
%Normalize columns
Ccol_normM = (sqrt(sum(CM.*CM,1)))';
WnM = diag(1./Ccol_normM); %Normalization matrix 
CnM = CM * WnM; %Column-normalized basis matrix

XiT = zeros(Nb,Ndofs);
XiT(3,1) = 1;
XiT(2,2) = -stiff/mass;
XiT(remove_basis,:) = [];

%% Zeroth iteration (no weighting)
for d = 1:Ndofs

    fprintf(['Degree of freedom: ', num2str(d),'\n'])
    
    b = dxData(:,d);
    Xitrue = XiT(:,d);
    
    %Define regularization parameter range
    lambda_min = eps;
%     lambda_max = max(abs(CM'*b));
    lambda_max = 0.1;
    
    lambdasLc = nlogspace(log(lambda_min),log(lambda_max),200);
    NlambdasLc = length(lambdasLc);

    tr_errLc = zeros(NlambdasLc,1);
    sol_errLc = zeros(NlambdasLc,1);
    sol_l1_normLc = zeros(NlambdasLc,1);
    
    itr2 = 1;
    lambdas = [lambda_min,lambda_max,0,0];
    gap = 1;
    
    tr_errs = zeros(1,4);
    sol_errs = zeros(1,4);
    sol_l1_norms = zeros(1,4);
    xis = zeros(1,4);
    etas = zeros(1,4);
    
    % Generate full Lcurve
    
    for s = 1:NlambdasLc %Regularization parameter
        
        lambdaLc = lambdasLc(s);
        fprintf(['Current sigma: ',num2str(lambdaLc),'\n'])
        
        %Solve training set
        
        y_tilde = SolveBP(CnM,b,Nbasis,100000,lambdaLc,1e-11);
        Xi = WnM*y_tilde;%De-normalize coefficients
                
        %Validate data
        tr_errLc(s) = norm(CM*Xi - b);
%         sol_errLc(s) = norm(Xi-Xitrue)/norm(Xitrue);
        sol_l1_normLc(s) = norm(y_tilde,1);
        
        xiLc(s) = log(tr_errLc(s));
        etaLc(s) = log(sol_l1_normLc(s));
        
    end
    
    %Normalize between -1 and 1
    CshxiLc = 1 - 2/(xiLc(end) - xiLc(1))*xiLc(end);
    CscxiLc = 2/(xiLc(end) - xiLc(1));
    CshetaLc = 1 - 2/(etaLc(1) - etaLc(end))*etaLc(1);
    CscetaLc = 2/(etaLc(1) - etaLc(end));
    
    xihatLc = CshxiLc + CscxiLc*xiLc;
    etahatLc = CshetaLc + CscetaLc*etaLc;
    
    tr_errLc_noise(j,d,1,:) = tr_errLc;
    sol_errLc_noise(j,d,1,:) = sol_errLc;
    sol_l1_normLc_noise(j,d,1,:) = sol_l1_normLc;
    
        
%     figLcurve = figure(1);
%     axLcurve = axes('Parent',figLcurve);
%     LcurvePlot = plot(axLcurve,xihatLc,etahatLc,'r.-');
%     ylabel('\eta = log(||x||_1)')
%     xlabel('\xi = log(||Ax - b||_2)')
%     grid on   
% 
%     indmin = find(sol_errLc == min(sol_errLc));
%     hold on
%     plot(axLcurve,xihatLc(indmin),etahatLc(indmin),'Color','g','Marker','.','MarkerSize',20)
%     drawnow
%     
%      
%     figError = figure(2);
%     axError = axes('Parent',figError);
%     ErrorPlot = loglog(axError,lambdasLc,sol_errLc,'r.-');
%     ylabel('log(||x - x^*||_2 / ||x^*||_2)')
%     xlabel('\lambda')
%     grid on
%     hold on
    
    while (gap > epsilon || itr2 < itr2_max)
        
    % Solve BPDN for extremals lambda_min and lambda_max
    if itr2 == 1
    for s = 1:2 %Regularization parameter
        
        lambda = lambdas(s);
        fprintf(['Current lambda: ',num2str(lambda),'\n'])
        
        %Solve for lambda_min  and lambda_max
        y_tilde = SolveBP(CnM,b,Nbasis,100000,lambda,1e-11);
        Xi = WnM*y_tilde;%De-normalize coefficients
        %Compute l2-norm of residual and l1-norm of solution
        tr_errs(s) = norm(CM*Xi - b);%/norm(dxData(:,d));
        sol_errs(s) = norm(Xi-Xitrue)/norm(Xitrue);
        sol_l1_norms(s) = norm(y_tilde,1);

        
        xis(s) = log(tr_errs(s));
        etas(s) = log(sol_l1_norms(s));
        
    end

    lambdas(3) = exp((log(lambdas(2)) + pGS*log(lambdas(1)))/(1+pGS));%Store lambda 2
    lambdas(4) = exp(log(lambdas(1)) + log(lambdas(2)) - log(lambdas(3)));%Store lambda 3

    %Solve BPDN for intermediate lambdas 2,3
    for s = 3:4 %Regularization parameter
        
        lambda = lambdas(s);
        fprintf(['Current lambda: ',num2str(lambda),'\n'])
        
        %Solve for lambda_min  and lambda_max
        y_tilde = SolveBP(CnM,b,Nbasis,100000,lambda,1e-11);
        Xi = WnM*y_tilde;%De-normalize coefficients
        
        %Compute l2-norm of residual and l1-norm of solution
        tr_errs(s) = norm(CM*Xi - b);%/norm(dxData(:,d));
        sol_errs(s) = norm(Xi-Xitrue)/norm(Xitrue);
        sol_l1_norms(s) = norm(y_tilde,1);
        
        xis(s) = log(tr_errs(s));
        etas(s) = log(sol_l1_norms(s));
        
    end
    
     %Normalize between -1 and 1
    Cshxi = 1 - 2/(xis(2) - xis(1))*xis(2);
    Cscxi = 2/(xis(2) - xis(1));
    Csheta = 1 - 2/(etas(1) - etas(2))*etas(1);
    Csceta = 2/(etas(1) - etas(2));
    xishat = Cshxi + Cscxi*xis;
    etashat = Csheta + Csceta*etas;
    
    %Sort points (xi,eta) corresponding to each lambda in ascending order

%     P = [xis(1),xis(2),xis(3),xis(4);etas(1),etas(2),etas(3),etas(4)];
    P = [xishat(1),xishat(2),xishat(3),xishat(4);etashat(1),etashat(2),etashat(3),etashat(4)];


    [lambdas, indx] = sort(lambdas);

    P = P(:,indx);%Sort points according to values of lambda in ascending order
       
%     plot(axLcurve,P(1,:),P(2,:),'Color','b','Marker','o')
%     drawnow
    end%End of loop for the first iteration
    
    %% Compute curvatures
    
    %Compute coordimates of the 4 current points
    C2 = menger2(P(:,1),P(:,2),P(:,3));
    C3 = menger2(P(:,2),P(:,3),P(:,4));

    while C3 < 0 %Check if the curvature is negative and update values
        
        %Reassign maximum and interior lambdas and Lcurve points (Golden search interval)
        lambdas(4) = lambdas(3);
        P(:,4) = P(:,3);
        lambdas(3) = lambdas(2);
        P(:,3) = P(:,2);
        
        %Update interior lambda and interior point
        lambdas(2) = exp((log(lambdas(4)) + pGS*log(lambdas(1)))/(1+pGS));
        
        %Solve for lambda2
        y_tilde = SolveBP(CnM,b,Nbasis,100000,lambdas(2),1e-11);
        Xi = WnM*y_tilde;%De-normalize coefficients
        
        %Compute l2-norm of residual and l1-norm of solution
        tr_err = norm(CM*Xi - b);%/norm(dxData(:,d));
%         sol_err = norm(Xi-Xitrue)/norm(Xitrue);
        sol_l1_norm = norm(y_tilde,1);

        
        xi = log(tr_err);
        eta = log(sol_l1_norm);
        
        xihat = Cshxi + Cscxi*xi;
        etahat = Csheta + Csceta*eta;
   
        %Normalize curve
         P(:,2) = [xihat;etahat];
        
        C3 = menger2(P(:,2),P(:,3),P(:,4));
        
    end
    
    if C2 > C3 %Update values depending on the curvature at the new points
        
        display('Curvature C2 is greater than C3');
        lambdaC = lambdas(2);
        
        %Reassign maximum and interior lambdas and Lcurve points (Golden search interval)
        lambdas(4) = lambdas(3);
        P(:,4) = P(:,3);
        
        lambdas(3) = lambdas(2);
        P(:,3) = P(:,2);
        
        %Update interior lambda and interior point
        lambdas(2) = exp((log(lambdas(4)) + pGS*log(lambdas(1)))/(1+pGS));
        
        %Solve for lambda2
        y_tilde = SolveBP(CnM,b,Nbasis,100000,lambdas(2),1e-11);
        Xi = WnM*y_tilde;%De-normalize coefficients
        
        %Compute l2-norm of residual and l1-norm of solution
        tr_err = norm(CM*Xi - b);%/norm(dxData(:,d));
%         sol_err = norm(Xi-Xitrue)/norm(Xitrue);
        sol_l1_norm = norm(y_tilde,1);

        xi = log(tr_err);
        eta = log(sol_l1_norm);

        xihat = Cshxi + Cscxi*xi;
        etahat = Csheta + Csceta*eta;

        P(:,2) = [xihat;etahat];
        
%         plot(axLcurve,xihat,etahat,'Color','k','Marker','o','MarkerSize',5,'LineStyle','none')
%         drawnow
%         plot(axError,lambdas(2),sol_err,'Color','k','Marker','o','MarkerSize',5,'LineStyle','none')
%         drawnow

    else
        display('Curvature C3 is greater than C2');
        lambdaC = lambdas(3);
        
        %Reassign maximum and interior lambdas and Lcurve points (Golden search interval)
        lambdas(1) = lambdas(2);
        P(:,1) = P(:,2);
        
        lambdas(2) = lambdas(3);
        P(:,2) = P(:,3);
        
        %Update interior lambda and interior point
        lambdas(3) = exp(log(lambdas(1)) + log(lambdas(4)) - log(lambdas(2)));
        
        %Solve for lambda3
        y_tilde = SolveBP(CnM,b,Nbasis,100000,lambdas(3),1e-11);
        Xi = WnM*y_tilde;%De-normalize coefficients
        
        %Compute l2-norm of residual and l1-norm of solution
        tr_err = norm(CM*Xi - b);%/norm(dxData(:,d));
%         sol_err = norm(Xi-Xitrue)/norm(Xitrue);
        sol_l1_norm = norm(y_tilde,1);

        xi = log(tr_err); 
        eta = log(sol_l1_norm);
         
        xihat = Cshxi + Cscxi*xi;
        etahat = Csheta + Csceta*eta;
        
        P(:,3) = [xihat;etahat];

%         plot(axLcurve,xihat,etahat,'Color','k','Marker','o','MarkerSize',5,'LineStyle','none')
%         drawnow
%         plot(axError,lambdas(2),sol_err,'Color','k','Marker','o','MarkerSize',5,'LineStyle','none')
%         drawnow

    end
    
    %Compute relative gap
    gap = (lambdas(4) - lambdas(1))/lambdas(4);
    lambda_itr2(itr2) = lambdaC;
    itr2 = itr2 + 1;
%     pause
    end
    
    %% Pick the corner
    lambda_corner = lambdaC;

    lambda_itr(1) = lambda_corner;
    fprintf(['Optimal sigma: ',num2str(lambda_corner)],'\n\n')

    % Solve L1 minimization with optimal sigma
    y_tilde = SolveBP(CnM,b,Nbasis,100000,lambda_corner,1e-11);
    Xi = WnM*y_tilde;%De-normalize coefficients
    coefferr(1) = norm(Xi - Xitrue)/norm(Xitrue);
    coefferr_noise(j,d,1) = coefferr(1);
    fprintf(['Coefficient error ',' = ',num2str(coefferr(1)),'\n'])
    % End of initial condition
    sol_l1_normCorner(j,d,1) = norm(y_tilde,1);
    tr_errsCorner(j,d,1) = norm(CM*Xi - b);
    
    fprintf('Zeroth iteration: \n')
%     Xi
%     pause
    
    fprintf('START ITERATIVE LOOP... \n\n')

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% START WEIGHTED ITERATIONS

    %Restart variables
    tr_errs = zeros(1,4);
    sol_errs = zeros(1,4);
    sol_l1_norms = zeros(1,4);
    xis = zeros(1,4);
    etas = zeros(1,4);
        
    for itr=1:num_itr
        
        %Apply weighting
        w = 1./(abs(Xi).^q+eps_w);%Compute weights
        Ww = diag(1./w); %Compute weighting/penalization matrix
        CnMw = CnM*Ww; %Weight CnM

        for s = 1:NlambdasLc %Regularization parameter
        
        lambdaLc = lambdasLc(s);
        fprintf(['Current lambda: ',num2str(lambdaLc),'\n'])
        
        %Solve training set
        
        y_tilde = SolveBP(CnMw,b,Nbasis,100000,lambdaLc,1e-11);
        y_hat = WnM*y_tilde;
        Xi = Ww*y_hat;%De-normalize coefficients
                
        %Validate data
        tr_errLc(s) = norm(CM*Xi - b);%/norm(dxData(:,d));
        sol_errLc(s) = norm(Xi-Xitrue)/norm(Xitrue);
        sol_l1_normLc(s) = norm(y_tilde,1);
        
        xiLc(s) = log(tr_errLc(s));
        etaLc(s) = log(sol_l1_normLc(s));
        
        end
        
         %Normalize between -1 and 1
        CshxiLc = 1 - 2/(xiLc(end) - xiLc(1))*xiLc(end);
        CscxiLc = 2/(xiLc(end) - xiLc(1));
        CshetaLc = 1 - 2/(etaLc(1) - etaLc(end))*etaLc(1);
        CscetaLc = 2/(etaLc(1) - etaLc(end));
    
        xihatLc = CshxiLc + CscxiLc*xiLc;
        etahatLc = CshetaLc + CscetaLc*etaLc;
        
        tr_errLc_noise(j,d,itr+1,:) = tr_errLc;
        sol_errLc_noise(j,d,itr+1,:) = sol_errLc;
        sol_l1_normLc_noise(j,d,itr+1,:) = sol_l1_normLc;
        
%         figLcurveIter = figure(3);
%         axLcurveIter = axes('Parent',figLcurveIter);
%         LcurvePlot = plot(axLcurveIter,xihatLc,etahatLc,'r.-');
%         ylabel('\eta = log(||x||_1)')
%         xlabel('\xi = log(||Ax - b||_2)')
%         grid on   
% 
%         indmin = find(sol_errLc == min(sol_errLc));
%         hold on
%         plot(axLcurveIter,xihatLc(indmin),etahatLc(indmin),'Color','g','Marker','.','MarkerSize',20)
%         drawnow
% 
%         figErrorIter = figure(4);
%         axErrorIter = axes('Parent',figErrorIter);
%         ErrorPlotIter = loglog(axErrorIter,lambdasLc,sol_errLc,'r.-');
%         ylabel('log(||x - x^*||_2 / ||x^*||_2)')
%         xlabel('\lambda')
%         grid on
%         hold on

%         Reset parameters   
        itr2 = 1;
        gap = 1;
        lambdas = [lambda_min,lambda_max,0,0];
        
        while (gap > epsilon || itr2 < itr2_max)
        
        %Solve BPDN for extremals lambda_min and lambda_max
        if itr2 == 1
            for s = 1:2 %Regularization parameter
        
            lambda = lambdas(s);
            fprintf(['Current lambda: ',num2str(lambda),'\n'])
        
            %Solve for lambda_min  and lambda_max
            y_tilde = SolveBP(CnMw,b,Nbasis,100000,lambda,1e-11);
            y_hat = WnM*y_tilde;%De-normalize coefficients
            Xi = Ww*y_hat;%Unweight coefficients
        
            %Compute l2-norm of residual and l1-norm of solution
            tr_errs(s) = norm(CM*Xi - b);
            sol_errs(s) = norm(Xi-Xitrue)/norm(Xitrue);
            sol_l1_norms(s) = norm(y_tilde,1);
        
            xis(s) = log(tr_errs(s));
            etas(s) = log(sol_l1_norms(s));
        
            end

        lambdas(3) = exp((log(lambdas(2)) + pGS*log(lambdas(1)))/(1+pGS));%Store lambda 2
        lambdas(4) = exp(log(lambdas(1)) + log(lambdas(2)) - log(lambdas(3)));%Store lambda 3

        %Solve BPDN for intermediate lambdas 2,3
        for s = 3:4 %Regularization parameter
        
            lambda = lambdas(s);
            fprintf(['Current lambda: ',num2str(lambda),'\n'])
        
            %Solve for lambda_min  and lambda_max
            y_tilde = SolveBP(CnMw,b,Nbasis,100000,lambda,1e-11);
            y_hat = WnM*y_tilde;%De-normalize coefficients
            Xi = Ww*y_hat;%De-normalize coefficients
        
            %Compute l2-norm of residual and l1-norm of solution
            tr_errs(s) = norm(CM*Xi - b);%/norm(dxData(:,d));
            sol_errs(s) = norm(Xi-Xitrue)/norm(Xitrue);
            sol_l1_norms(s) = norm(y_tilde,1);
        
            xis(s) = log(tr_errs(s));
            etas(s) = log(sol_l1_norms(s));
        
        end
    
        %Normalize between -1 and 1
        Cshxi = 1 - 2/(xis(2) - xis(1))*xis(2);
        Cscxi = 2/(xis(2) - xis(1));
        Csheta = 1 - 2/(etas(1) - etas(2))*etas(1);
        Csceta = 2/(etas(1) - etas(2));
        xishat = Cshxi + Cscxi*xis;
        etashat = Csheta + Csceta*etas;
        
        %Sort points (xi,eta) corresponding to each lambda in ascending order
        %(lmin < l2 < l3 < lmax)
        P = [xishat(1),xishat(2),xishat(3),xishat(4);etashat(1),etashat(2),etashat(3),etashat(4)];
        
        [lambdas, indx] = sort(lambdas);
        P = P(:,indx);%Sort points according to values of lambda in ascending order

%         plot(axLcurveIter,P(1,:),P(2,:),'Color','b','Marker','o')
%         drawnow

        end%End of loop for the first iteration

    %% Compute curvatures

    %Compute coordimates of the 4 current points
    C2 = menger2(P(:,1),P(:,2),P(:,3));
    C3 = menger2(P(:,2),P(:,3),P(:,4));

    while C3 < 0 %Check if the curvature is negative and update values
        
        %Reassign maximum and interior lambdas and Lcurve points (Golden search interval)
        lambdas(4) = lambdas(3);
        P(:,4) = P(:,3);
        lambdas(3) = lambdas(2);
        P(:,3) = P(:,2);
        
        %Update interior lambda and interior point
        lambdas(2) = exp((log(lambdas(4)) + pGS*log(lambdas(1)))/(1+pGS));
        
        %Solve for lambda2
        y_tilde = SolveBP(CnMw,b,Nbasis,100000,lambdas(2),1e-11);
        y_hat = WnM*y_tilde;%De-normalize coefficients  
        Xi = Ww*y_hat;%De-normalize coefficients
        
        %Compute l2-norm of residual and l1-norm of solution
        tr_err = norm(CM*Xi - b);%/norm(dxData(:,d));
%         sol_err = norm(Xi-Xitrue)/norm(Xitrue)
        sol_l1_norm = norm(y_tilde,1);
        
        xi = log(tr_err);
        eta = log(sol_l1_norm);
        
         xihat = Cshxi + Cscxi*xi;
        etahat = Csheta + Csceta*eta;
        
        P(:,2) = [xihat;etahat];
        
        C3 = menger2(P(:,2),P(:,3),P(:,4));
        
    end
    
    if C2 > C3 %Update values depending on the curvature at the new points
        
        display('Curvature C2 is greater than C3');
        lambdaC = lambdas(2);
        
        %Reassign maximum and interior lambdas and Lcurve points (Golden search interval)
        lambdas(4) = lambdas(3);
        P(:,4) = P(:,3);
        
        lambdas(3) = lambdas(2);
        P(:,3) = P(:,2);
        
        %Update interior lambda and interior point
        lambdas(2) = exp((log(lambdas(4)) + pGS*log(lambdas(1)))/(1+pGS));
        
        %Solve for lambda2
        y_tilde = SolveBP(CnMw,b,Nbasis,100000,lambdas(2),1e-11);
        y_hat = WnM*y_tilde;%De-normalize coefficients  
        Xi = Ww*y_hat;%De-normalize coefficients
        
        %Compute l2-norm of residual and l1-norm of solution
        tr_err = norm(CM*Xi - b);%/norm(dxData(:,d));
        lambdas(2)
%         sol_err = norm(Xi-Xitrue)/norm(Xitrue)
        sol_l1_norm = norm(y_tilde,1);
 
        xi = log(tr_err);
        eta = log(sol_l1_norm);
        
        xihat = Cshxi + Cscxi*xi;
        etahat = Csheta + Csceta*eta;
        
        P(:,2) = [xihat;etahat];

%         plot(axLcurveIter,xihat,etahat,'Color','k','Marker','o','MarkerSize',5,'LineStyle','none')
%         drawnow
%         plot(axErrorIter,lambdas(2),sol_err,'Color','k','Marker','o','MarkerSize',5,'LineStyle','none')
%         drawnow
    
    else
        display('Curvature C3 is greater than C2');
        lambdaC = lambdas(3);
        
        %Reassign maximum and interior lambdas and Lcurve points (Golden search interval)
        lambdas(1) = lambdas(2);
        P(:,1) = P(:,2);
        
        lambdas(2) = lambdas(3);
        P(:,2) = P(:,3);
        
        %Update interior lambda and interior point
        lambdas(3) = exp(log(lambdas(1)) + log(lambdas(4)) - log(lambdas(2)));
        
        %Solve for lambda3
        y_tilde = SolveBP(CnMw,b,Nbasis,100000,lambdas(3),1e-11);
        y_hat = WnM*y_tilde;%De-normalize coefficients 
        Xi = Ww*y_hat;%De-normalize coefficients
        
        %Compute l2-norm of residual and l1-norm of solution
        tr_err = norm(CM*Xi - b);%/norm(dxData(:,d));
        lambdas(3)
%         sol_err = norm(Xi-Xitrue)/norm(Xitrue)
        sol_l1_norm = norm(y_tilde,1);
        
        xi = log(tr_err); 
        eta = log(sol_l1_norm);
        
        xihat = Cshxi + Cscxi*xi;
        etahat = Csheta + Csceta*eta;
        
        P(:,3) = [xihat;etahat];
    
%         plot(axLcurveIter,xihat,etahat,'Color','k','Marker','o','MarkerSize',5,'LineStyle','none')
%         drawnow
%         plot(axErrorIter,lambdas(2),sol_err,'Color','k','Marker','o','MarkerSize',5,'LineStyle','none')
%         drawnow
        
    end
    
    %Compute relative gap
    
    gap = (lambdas(4) - lambdas(1))/lambdas(4);
    lambda_itr2(itr2) = lambdaC;
    itr2 = itr2 + 1;    
    
        end
%     pause
%     close(figLcurveIter)
%     close(figErrorIter)
    
    %% Pick the corner
    lambda_corner = lambdaC;
    lambda_itr(itr) = lambda_corner;
    fprintf(['Optimal lambda: ',num2str(lambda_corner)],'\n\n')

        
        % Solve L1 minimization with optimal sigma
        y_tilde = SolveBP(CnMw,b,Nbasis,100000,lambda_corner,1e-11);
        Xi = Ww*WnM*y_tilde%De-normalize coefficients
        coefferr(itr+1) = norm(Xi - Xitrue)/norm(Xitrue)
        fprintf(['Coefficient error',' = ',num2str(coefferr(itr)),'\n'])
        lambda_corner
        
        sol_l1_normCorner(j,d,itr+1) = norm(y_tilde,1);
        tr_errsCorner(j,d,itr+1) = norm(CM*Xi - b);
        
%         pause
%         close all
    coefferr_noise(j,d,itr+1) = coefferr(itr+1)
    end
    
    Xi_noise(j,d,index_basis) = Xi;

    
end%End loop for degrees of freedom


end%End loop for noise levels
        

save('EulerRBD_Data_Plots_1000_MOD','Xi_noise','coefferr_noise','tr_errLc_noise','sol_errLc_noise','sol_l1_normLc_noise','sol_l1_normCorner','tr_errsCorner','sigmas','LD_noise')








 