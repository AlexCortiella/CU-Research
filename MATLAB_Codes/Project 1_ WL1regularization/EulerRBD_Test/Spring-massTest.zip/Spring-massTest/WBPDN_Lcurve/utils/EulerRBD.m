function dxdt = EulerRBD(t,x,param)

%Extract parameters
Ip = diag(param(1:3));

%Forcing function (input)
T = Torque(t,x,param);

%Extract dynamic and kinematic states
w = zeros(3,1);
q = zeros(4,1);
w(:,1) = x(1:3);%Angular velocity vector [w1;w2;w3]
q(:,1) = x(4:7);%Attitude quaternion vector [q1;q2;q3;q0];
q = q/norm(q);%Normalize quaternion to avoid propagation on numerical errors

%Time derivative (angular acceleration)

%Rotational dynamics
dwdt = Ip\(T - cross(w,Ip*w));

%Attitude kinematics (attitude quaternion body principal axes -> orbit LVLH frames)
% Tq = Thetaq(q);
%     
% dqdt = 0.5*Tq*w;

dqdt = 0.5*[q(4)*w(1) - q(3)*w(2) + q(2)*w(3);...
            q(3)*w(1) + q(4)*w(2) - q(1)*w(3);...
            -q(2)*w(1) + q(1)*w(2) + q(4)*w(3);...
            -q(1)*w(1) - q(2)*w(2) - q(3)*w(3)];


%Time derivative of the state vector
dxdt = [dwdt;dqdt];

end

