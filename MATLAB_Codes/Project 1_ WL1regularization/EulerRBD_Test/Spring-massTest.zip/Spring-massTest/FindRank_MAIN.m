%% Solve 1 dof linear/quadratic undamped, unforced, oscillator problem
clc;
close all;
clear all;
addpath('./utils','./Solvers')
n = 2; %# state variables;
%Number of samples after trimming the ends
m = 100; %Number of samples after trimming

stiff = 10;
mass = 1;
E = 5;
a = sqrt(2*E/stiff);
b = sqrt(2*E/mass);
t = 2*pi.*rand(m,1);
xData = zeros(m,n);

xData(:,1) = a.*cos(t);
xData(:,2) = b.*sin(t);

figure;
title('Constraint manifold');
plot(xData(:,1),xData(:,2),'r.');
xlabel('x')
ylabel('y')
xlim([-4,4])
ylim([-4,4])
grid on
axis('square')

%Randomize values of the states
%% Original basis
p = 2;%polynomial order 
Nb = nchoosek(p+n,n);
index_pc = nD_polynomial_array(n,p);
C = zeros(m,Nb);
for isim = 1:m
    crow = piset_monomial(xData(isim,:),index_pc);
    C(isim,:) = crow(1:Nb);
end

% Find rank of Caug
rank(C)


%Normalize columns
Ccol_norm = (sqrt(sum(C.*C,1)))';
Wn = diag(1./Ccol_norm); %Normalization matrix 
Cn = C * Wn; %Column-normalized basis matrix

CorrM = Cn'*Cn;

% figure;
% imagesc(CorrM);
% title('Correlation matrix')
% colormap(jet);
% colorbar;

cond(C)
cond(Cn)

[U,S,V] = svd(C);

figure
semilogy(diag(S),'ro','MarkerFaceColor',[1,0,0]);
% set(gcf,'interpreter','latex')
title('Singular values of ');
axis('square')
grid on
%ix gives the column number of all independent columns of the matrix Cn
%Each column of the matrix P gives the linear dependencies of the columns
%of Cn in terms of the independent columns given in ix
[P,ix] = matrixID(Cn,10^-12);

norm(Cn(:,ix)*P-Cn)/norm(Cn)

LDn = zeros(Nb);
LDn(ix,:) = P;
LD = LDn.*repmat(1./Ccol_norm,1,Nb).*repmat(Ccol_norm',Nb,1);

figure
imagesc(LDn);
colormap(jet);
colorbar;
axis('square')
pause
close






