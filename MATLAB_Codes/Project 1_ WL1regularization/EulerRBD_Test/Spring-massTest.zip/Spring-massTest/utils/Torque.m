function [T] = Torque(t,x,param)

% Inertia of spacecraft
Ip = diag(param(1:3));

% Orbit parameter
alpha = param(4); % = 3mu/R^3

% Extract attitude quaternion 
q = x(4:7);

%Transform nadir vector (LVLH orbit frame) to body frame
n = DCMq(q)*[0;0;1];

T = alpha*cross(n,Ip*n);
end

function A = DCMq(q)

A = (q(4)*q(4) - norm(q(1:3))^2)*eye(3) - 2*q(4)*skew(q(1:3)) + 2*q(1:3)*q(1:3)';

end

function S = skew(x)

S = [0, -x(3), x(2);...
     x(3), 0, -x(1);...
     -x(2), x(1), 0];
 
end

