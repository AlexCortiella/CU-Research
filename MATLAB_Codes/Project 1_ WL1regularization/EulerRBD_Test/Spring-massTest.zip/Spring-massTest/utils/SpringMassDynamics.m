function dxdt = SpringMassDynamics(t,x,param)

m = param(1);
k = param(2);

omega2 = k/m;

%Time derivative of the state vector
dxdt = [x(2); -omega2*x(1)];

end

