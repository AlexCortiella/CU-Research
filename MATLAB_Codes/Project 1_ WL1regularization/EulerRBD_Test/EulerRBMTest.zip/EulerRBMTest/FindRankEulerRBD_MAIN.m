%% Solve 1 dof linear/quadratic undamped, unforced, oscillator problem
clc;
close all;
clear all;
addpath('./utils','./Solvers')
n = 3; %# state variables;
%Number of samples after trimming the ends
m = 1000; %Number of samples after trimming

alpha = 1;
beta = 2;
gamma = 3;
T = 0.5;
a = sqrt(2*T/alpha);
b = sqrt(2*T/beta);
c = sqrt(2*T/gamma);
u = 2*pi.*rand(m,1);
v = 2*pi.*rand(m,1);

xData = zeros(m,n);

xData(:,1) = a.*cos(u).*sin(v);
xData(:,2) = b.*sin(u).*sin(v);
xData(:,3) = c.*cos(v);


figure;
title('Constraint manifold');
plot3(xData(:,1),xData(:,2),xData(:,3),'r.');
xlabel('x_1')
ylabel('x_2')
zlabel('x_3')

grid on
axis('equal')

%Randomize values of the states
%% Original basis
p = 3;%polynomial order 
Nb = nchoosek(p+n,n);
index_pc = nD_polynomial_array(n,p);
C = zeros(m,Nb);
for isim = 1:m
    crow = piset_monomial(xData(isim,:),index_pc);
    C(isim,:) = crow(1:Nb);
end

% Find rank of Caug
rank(C)


%Normalize columns
Ccol_norm = (sqrt(sum(C.*C,1)))';
Wn = diag(1./Ccol_norm); %Normalization matrix 
Cn = C * Wn; %Column-normalized basis matrix

CorrM = Cn'*Cn;

figure;
imagesc(CorrM);
title('Correlation matrix')
colormap(jet);
colorbar;

cond(C)
cond(Cn)

[U,S,V] = svd(C);

figure;
subplot(1,2,1)
semilogy(diag(S),'ro','MarkerFaceColor',[1,0,0]);
title('Singular values of C');
axis('square')

%ix gives the column number of all independent columns of the matrix Cn
%Each column of the matrix P gives the linear dependencies of the columns
%of Cn in terms of the independent columns given in ix
[P,ix] = matrixID(Cn,10^-12);

norm(Cn(:,ix)*P-Cn)/norm(Cn)

LDn = zeros(Nb);
LDn(ix,:) = P;
LD = LDn.*(1./Ccol_norm).*Ccol_norm';
LD
subplot(1,2,2)
imagesc(LDn);
title('Linear dependence matrix')
colormap(jet);
colorbar;
axis('square')
pause
close

remove_basis = setdiff(1:Nb,ix);
CM = C;
CM(:,remove_basis) = [];
cond(C)
cond(CM)






