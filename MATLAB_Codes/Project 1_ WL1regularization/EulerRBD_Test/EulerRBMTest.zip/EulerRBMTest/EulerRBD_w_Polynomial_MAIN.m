%% Solve 1 dof linear/quadratic undamped, unforced, oscillator problem
clc;
close all;
clear all;
addpath('./utils','./Solvers','./regtools')
% rng(100);

%% Dynamical system parameters
%System parameters (Principal moments of inertia)
I1 = 1;
I2 = 1;
I3 = 2;

alpha = 0; %Apply gravity gradient torque;
param = [I1;I2;I3;alpha];
n = 3; %# state variables;

%Number of samples after trimming the ends
m = 500; %Number of samples after trimming

%Time parameters
dt = 0.001;
t0 = 0;
tf = 20;

%Intial conditions
% q0 = [0;0;0;1];
% w0 = [1;0;0.5];
w0 = [1;1;1];

%Kinetic energy (conserved in torque-free motion)
T = 0.5*w0'*diag([I1,I2,I3])*w0

%Angular momentum (conserved in torque-free motion)
H = diag([I1,I2,I3])*w0;
H2 = H'*H

x0 = [w0];

polhodeplot(I1,I2,I3,w0)
pause
close
% time_anim = linspace(0,100,1000);
% poinsot_construction([I1,I2,I3],w0',time_anim,1)
% 
% pause
tspanf = t0:dt:(tf-dt);

%State sapace model of a 2nd order linear differential equation
options = odeset('RelTol',1e-10,'AbsTol',1e-10*ones(1,n));
[xf] = ode5(@(t,x) EulerDynamics_w(t,x,param),tspanf,x0');
x = xf;
t = tspanf';

%Verify that the states satisfy physical constraints
Ttrue = 0.5*(I1*x(:,1).^2 + I2*x(:,2).^2 + I3*x(:,3).^2);
H2true = I1^2*x(:,1).^2 + I2^2*x(:,2).^2 + I3^2*x(:,3).^2;
H_1 = I1*x(:,1);H_2 = I2*x(:,2);H_3 = I3*x(:,3);

figure;
plot(t,Ttrue,'r');
hold on
plot(t,H2true,'b');
plot(t,H_1,'r--');
plot(t,H_2,'g--');
plot(t,H_3,'b--');
xlabel('Time')
legend('Kinetic energy','H^2','H_1','H_2','H_3')
pause
close

%% Sample dynamical system
dsample = length(t)/m;
timeData = t(1:dsample:end);
Nsamples = length(timeData);

%% True state variables
wtrue = x(1:dsample:end,1:3);
xDataT = [wtrue];

%% Noisy states
eta = 0;
wnoisy = wtrue + eta*randn(Nsamples,n);
xDataN = wnoisy;

%% Verify constraints
c1 = rand
c2 = rand

eta1 = I1*(c1 + c2*I1)/(2*c1*T + c2*H2)
eta2 = I2*(c1 + c2*I2)/(2*c1*T + c2*H2)
eta3 = I3*(c1 + c2*I3)/(2*c1*T + c2*H2)
Cver = eta1*xDataN(:,1).^2 + eta2*xDataN(:,2).^2 + eta3*xDataN(:,3).^2;
mean(Cver)

%% True state derivatives
dwtrue = zeros(Nsamples,3);
Ip = diag(param(1:3));

for k = 1:Nsamples
dwtrue(k,:) = (Ip\( - cross(wtrue(k,:)',Ip*wtrue(k,:)')))';
end
dxDataT = [dwtrue];
%% Compute derivatives from nosiy data
%Obtain derivatives
[xDataNt,dxDataNt,dxDataTt,timeDatat] = TikDiffLcurve(xDataN,dxDataT,timeData);
Nsamples = size(xDataNt,1);
xDataN = xDataNt;
dxDataN = dxDataNt;
dxDataT = dxDataTt;
timeData = timeDatat;
Tnoisy = 0.5*(I1*xDataN(:,1).^2 + I2*xDataN(:,2).^2 + I3*xDataN(:,3).^2);
H2noisy = I1^2*xDataN(:,1).^2 + I2^2*xDataN(:,2).^2 + I3^2*xDataN(:,3).^2;




figure(1);
subplot(5,1,1);
plot(timeData, xDataN(:,1),'r.')
xlabel('Time')
ylabel('\omega_1(t)')

subplot(5,1,2);
plot(timeData, xDataN(:,2),'r.')
xlabel('Time')
ylabel('\omega_2(t)')

subplot(5,1,3);
plot(timeData, xDataN(:,3),'r.')
xlabel('Time')
ylabel('\omega_3(t)')

subplot(5,1,4);
plot(timeData, Tnoisy,'r.')
xlabel('Time')
ylabel('2T')

subplot(5,1,5);
plot(timeData, H2noisy,'r.')
xlabel('Time')
ylabel('H^2')

pause
close all

figure(2);
subplot(3,1,1);
plot(timeData, dxDataN(:,1),'r.')
xlabel('Time')
ylabel('\omega_1(t)')

subplot(3,1,2);
plot(timeData, dxDataN(:,2),'r.')
xlabel('Time')
ylabel('\omega_2(t)')

subplot(3,1,3);
plot(timeData, dxDataN(:,3),'r.')
xlabel('Time')
ylabel('\omega_3(t)')

pause
close all


p = 2;%polynomial order 
Nb = nchoosek(p+n,n);
index_pc = nD_polynomial_array(n,p);

% True coefficient vector in monomial basis
XiT = zeros(Nb,n);

% XiT(9,1) = (I2-I3)/I1;
% XiT(8,2) = (I3-I1)/I2;
% XiT(6,3) = (I1-I2)/I3;

XiT(11,1) = (I2-I3)/I1;
XiT(10,2) = (I3-I1)/I2;
XiT(8,3) = (I1-I2)/I3;

C = zeros(Nsamples,Nb);
for isim = 1:Nsamples
    crow = piset_monomial(xDataN(isim,:),index_pc);
    C(isim,:) = crow(1:Nb);
end

%Normalize columns
Ccol_norm = (sqrt(sum(C.*C,1)))';
Wn = diag(1./Ccol_norm); %Normalization matrix 
Cn = C * Wn; %Column-normalized basis matrix

CorrM = Cn'*Cn;

figure;
imagesc(CorrM);
title('Correlation matrix')
colormap(jet);
colorbar;

cond(C)
cond(Cn)

[U,S,V] = svd(C);

figure;
subplot(1,2,1)
semilogy(diag(S),'ro','MarkerFaceColor',[1,0,0]);
% hold on
% semilogy([0 Nb],[tol tol],'k');
title('Singular values of C');
axis('square')

%ix gives the column number of all independent columns of the matrix Cn
%Each column of the matrix P gives the linear dependencies of the columns
%of Cn in terms of the independent columns given in ix

% [P,ix,k] = matrixIDvR(Cn,Nb);
[P,ix] = matrixID(Cn,1e-12);


norm(Cn(:,ix)*P-Cn)/norm(Cn)

LDn = zeros(Nb);
LDn(ix,:) = P;
LD = LDn.*(1./Ccol_norm).*Ccol_norm';

subplot(1,2,2)
imagesc(LD);
title('Linear dependence matrix')
colormap(jet);
colorbar;
axis('square')
maxrankM = input('Please, select the rank of C: ')
remove_basis = input('Please, select basis to remove: ')
close

[PM,ixM,kM] = matrixIDvR(Cn,maxrankM);
LDnM = zeros(Nb);
LDnM(ixM,:) = PM;
LDM = LDnM.*(1./Ccol_norm).*Ccol_norm'

figure
imagesc(LDnM);
title('Linear dependence matrix')
colormap(jet);
colorbar;
axis('square')
pause
close

%% Solve noisless case using least squares in a polynomial basis of order p with n states

Xi_LS = C\dxDataN;

%Xi_LS(abs(Xi_LS) < 0.0001) = 0 %Treshold small coefficients due to numerical errors (make sure that the true coefficients exceed the treshold value)
Xi_LS
index_pc
pause

%% Solve noisless case using BPDN in a polynomial basis of order p with n states
lambda = eps;
Xi_BPDN = zeros(Nb,n);

for d = 1:n

b = dxDataN(:,d);
y_BPDN = SolveBP(Cn,b,Nb,100000,lambda,1e-11);
Xi_BPDN(:,d) = Wn*y_BPDN;

end

%Xi_BPDN(abs(Xi_BPDN) < 0.0001) = 0 %Treshold small coefficients due to numerical errors (make sure that the true coefficients exceed the treshold value)
Xi_BPDN
index_pc

pause

%% Compute residuals %%

res_LS = C*Xi_LS - dxDataN;

resw1_LS = rms(res_LS(:,1));
resw2_LS = rms(res_LS(:,2));
resw3_LS = rms(res_LS(:,3));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

res_BPDN = C*Xi_BPDN - dxDataN;

resw1_BPDN = rms(res_BPDN(:,1));
resw2_BPDN = rms(res_BPDN(:,2));
resw3_BPDN = rms(res_BPDN(:,3));

%% Prediction %%

tini = 0;
dt = 0.001;
tend = 100;
tpred = tini:dt:tend;

% Exact trajectory
options = odeset('RelTol',1e-10,'AbsTol',1e-10*ones(1,n));
[t_exact, x_exact] = ode45(@(t,x) EulerDynamics_w(t,x,param),tpred,x0',options);

% LS trajectory
[t_LS, x_LS] = ode45(@(t,x) predictDynamicsM(t,x,Xi_LS,index_pc),tpred,x0',options);

% BPDN trajectory
[t_BPDN, x_BPDN] = ode45(@(t,x) predictDynamicsM(t,x,Xi_BPDN,index_pc),tpred,x0',options);


figure;
suptitle('LS')
subplot(3,1,1);
plot(t_exact,x_exact(:,1),'g');
hold on
plot(t_LS,x_LS(:,1),'r--');
xlabel('Time')
ylabel('\omega_1(t)')

subplot(3,1,2);
plot(t_exact,x_exact(:,2),'g');
hold on
plot(t_LS,x_LS(:,2),'r--');
xlabel('Time')
ylabel('\omega_2(t)')

subplot(3,1,3);
plot(t_exact,x_exact(:,3),'g');
hold on
plot(t_LS,x_LS(:,3),'r--');
xlabel('Time')
ylabel('\omega_3(t)')

figure;
suptitle('BPDN')
subplot(3,1,1);
plot(t_exact,x_exact(:,1),'g');
hold on
plot(t_BPDN,x_BPDN(:,1),'r--');
xlabel('Time')
ylabel('\omega_1(t)')

subplot(3,1,2);
plot(t_exact,x_exact(:,2),'g');
hold on
plot(t_BPDN,x_BPDN(:,2),'r--');
xlabel('Time')
ylabel('\omega_2(t)')

subplot(3,1,3);
plot(t_exact,x_exact(:,3),'g');
hold on
plot(t_BPDN,x_BPDN(:,3),'r--');
xlabel('Time')
ylabel('\omega_3(t)')
pause
close all
%Compute rmse between exact and identified trajectories

%% LS

etraj_LS = x_LS - x_exact;

RMSEw1_LS = rms(etraj_LS(:,1))
RMSEw2_LS = rms(etraj_LS(:,2))
RMSEw3_LS = rms(etraj_LS(:,3))

%% BPDN

etraj_BPDN = x_BPDN - x_exact;

RMSEw1_BPDN = rms(etraj_BPDN(:,1))
RMSEw2_BPDN = rms(etraj_BPDN(:,2))
RMSEw3_BPDN = rms(etraj_BPDN(:,3))

pause
%%%%%%%%%%%%%%%%% MODIFY BASIS MATRIX REMOVING LINEARLY DEPENDENT COLUMNS %%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Remove linearly dependent columns
% remove_basis = [1];
index_basis = 1:Nb;
CM = C; CM(:,remove_basis) = [];
index_pcM = index_pc;
index_basis(remove_basis) = [];
index_pcM(remove_basis,:) = [];
NbM = size(CM,2);

%Normalize columns
Ccol_normM = (sqrt(sum(CM.*CM,1)))';
WnM = diag(1./Ccol_normM); %Normalization matrix 
CnM = CM * WnM; %Column-normalized basis matrix

cond(C)
cond(Cn)

[UM,SM,VM] = svd(CM);
maxrnkM = NbM;

figure;
subplot(1,2,1)
semilogy(diag(SM),'ro','MarkerFaceColor',[1,0,0]);
% hold on
% semilogy([0 Nb],[tol tol],'k');
title('Singular values of CM');
axis('square')

%ix gives the column number of all independent columns of the matrix Cn
%Each column of the matrix P gives the linear dependencies of the columns
%of Cn in terms of the independent columns given in ix

[PM,ixM,k] = matrixIDvR(CnM,maxrnkM);
% [P,ix] = matrixID(Cn,1e-12);


norm(CnM(:,ixM)*PM-CnM)/norm(CnM)

LDM = zeros(NbM);
LDM(ixM,:) = PM;
LDM

subplot(1,2,2)
imagesc(LDM);
title('Linear dependence matrix (reduced basis)')
colormap(jet);
colorbar;
axis('square')
pause
close

%% Solve noisless case using least squares in a polynomial basis of order p with n states
Xi_LSM1 = CM\dxDataN;

%Xi_LS(abs(Xi_LS) < 0.0001) = 0 %Treshold small coefficients due to numerical errors (make sure that the true coefficients exceed the treshold value)
Xi_LSM = zeros(Nb,n);
Xi_LSM(index_basis,:) = Xi_LSM1;
Xi_LSM

pause

%% Solve noisless case using BPDN in a polynomial basis of order p with n states
lambda = eps;
Xi_BPDNM = zeros(Nb,n);

for d = 1:n

b = dxDataN(:,d);
y_BPDN = SolveBP(CnM,b,NbM,100000,lambda,1e-11);
Xi_BPDNM1(:,d) = WnM*y_BPDN;

end
Xi_BPDNM(index_basis,:) = Xi_BPDNM1;

%Xi_BPDN(abs(Xi_BPDN) < 0.0001) = 0 %Treshold small coefficients due to numerical errors (make sure that the true coefficients exceed the treshold value)
Xi_BPDNM
pause

%% Compute residuals %%

res_LSM = C*Xi_LSM - dxDataN;

resw1_LSM = rms(res_LSM(:,1));
resw2_LSM = rms(res_LSM(:,2));
resw3_LSM = rms(res_LSM(:,3));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

res_BPDNM = C*Xi_BPDNM - dxDataN;

resw1_BPDNM = rms(res_BPDNM(:,1));
resw2_BPDNM = rms(res_BPDNM(:,2));
resw3_BPDNM = rms(res_BPDNM(:,3));

%% Prediction %%

tini = 0;
dt = 0.001;
tend = 100;
tpred = tini:dt:tend;

% Exact trajectory
options = odeset('RelTol',1e-10,'AbsTol',1e-10*ones(1,n));
[t_exactM, x_exactM] = ode45(@(t,x) EulerDynamics_w(t,x,param),tpred,x0',options);

% LS trajectory
[t_LSM, x_LSM] = ode45(@(t,x) predictDynamicsM(t,x,Xi_LSM,index_pc),tpred,x0',options);

% BPDN trajectory
[t_BPDNM, x_BPDNM] = ode45(@(t,x) predictDynamicsM(t,x,Xi_BPDNM,index_pc),tpred,x0',options);


figure;
suptitle('LS reduced basis')
subplot(3,1,1);
plot(t_exactM,x_exactM(:,1),'g');
hold on
plot(t_LSM,x_LSM(:,1),'r--');
xlabel('Time')
ylabel('\omega_1(t)')

subplot(3,1,2);
plot(t_exactM,x_exactM(:,2),'g');
hold on
plot(t_LSM,x_LSM(:,2),'r--');
xlabel('Time')
ylabel('\omega_2(t)')

subplot(3,1,3);
plot(t_exactM,x_exactM(:,3),'g');
hold on
plot(t_LSM,x_LSM(:,3),'r--');
xlabel('Time')
ylabel('\omega_3(t)')

figure;
suptitle('BPDN reduced basis')
subplot(3,1,1);
plot(t_exactM,x_exactM(:,1),'g');
hold on
plot(t_BPDNM,x_BPDNM(:,1),'r--');
xlabel('Time')
ylabel('\omega_1(t)')

subplot(3,1,2);
plot(t_exactM,x_exactM(:,2),'g');
hold on
plot(t_BPDNM,x_BPDNM(:,2),'r--');
xlabel('Time')
ylabel('\omega_2(t)')

subplot(3,1,3);
plot(t_exactM,x_exactM(:,3),'g');
hold on
plot(t_BPDNM,x_BPDNM(:,3),'r--');
xlabel('Time')
ylabel('\omega_3(t)')

%Compute rmse between exact and identified trajectories

%% LS

etraj_LSM = x_LSM - x_exactM;

RMSEw1_LSM = rms(etraj_LSM(:,1))
RMSEw2_LSM = rms(etraj_LSM(:,2))
RMSEw3_LSM = rms(etraj_LSM(:,3))

%% BPDN

etraj_BPDNM = x_BPDNM - x_exactM;

RMSEw1_BPDNM = rms(etraj_BPDNM(:,1))
RMSEw2_BPDNM = rms(etraj_BPDNM(:,2))
RMSEw3_BPDNM = rms(etraj_BPDNM(:,3))


for d = 1:n
solerr_LS(d) = norm(Xi_LS(:,d) - XiT(:,d))/norm(XiT(:,d));
solerr_LSM(d) = norm(Xi_LSM(:,d) - XiT(:,d))/norm(XiT(:,d));

solerr_BPDN(d) = norm(Xi_BPDN(:,d) - XiT(:,d))/norm(XiT(:,d));

solerr_BPDNM(d) = norm(Xi_BPDNM(:,d) - XiT(:,d))/norm(XiT(:,d));
end


solerr_LS
solerr_LSM
solerr_BPDN
solerr_BPDNM


%Verify constraints



