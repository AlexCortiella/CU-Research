%% Solve 1 dof linear/quadratic undamped, unforced, oscillator problem
clc;
close all;
clear all;
addpath('./utils','./Solvers','./regtools')
% rng(100);

%% Dynamical system parameters
%System parameters (Principal moments of inertia)
I1 = 1;
I2 = 2;
I3 = 3;

alpha = 0; %Apply gravity gradient torque;
param = [I1;I2;I3;alpha];
n = 3; %# state variables;

%Number of samples after trimming the ends
m = 1000; %Number of samples after trimming

%Time parameters
dt = 0.001;
t0 = 0;
tf = 20;

%Intial conditions
% q0 = [0;0;0;1];
% w0 = [1;0;0.5];
w0 = [1;1;1];

%Kinetic energy (conserved in torque-free motion)
T = 0.5*w0'*diag([I1,I2,I3])*w0

%Angular momentum (conserved in torque-free motion)
H = diag([I1,I2,I3])*w0;
H2 = H'*H

x0 = [w0];

polhodeplot(I1,I2,I3,w0)
pause
close
% time_anim = linspace(0,100,1000);
% poinsot_construction([I1,I2,I3],w0',time_anim,1)
% 
% pause
tspanf = t0:dt:(tf-dt);

%State sapace model of a 2nd order linear differential equation
options = odeset('RelTol',1e-10,'AbsTol',1e-10*ones(1,n));
[xf] = ode5(@(t,x) EulerDynamics_w(t,x,param),tspanf,x0');
x = xf;
t = tspanf';

%Verify that the states satisfy physical constraints
Ttrue = 0.5*(I1*x(:,1).^2 + I2*x(:,2).^2 + I3*x(:,3).^2);
H2true = I1^2*x(:,1).^2 + I2^2*x(:,2).^2 + I3^2*x(:,3).^2;
H_1 = I1*x(:,1);H_2 = I2*x(:,2);H_3 = I3*x(:,3);

figure(2);
plot(t,Ttrue,'r');
hold on
plot(t,H2true,'b');
plot(t,H_1,'r--');
plot(t,H_2,'g--');
plot(t,H_3,'b--');
xlabel('Time')
legend('Kinetic energy','H^2','H_1','H_2','H_3')
pause
close

xData = x(1:length(tspanf)/m:end,:);

p = 2;
index_pc = nD_polynomial_array(n,p);
Nb = size(index_pc,1);

C = zeros(m,Nb);
for isim = 1:m
    crow = piset_monomial(xData(isim,:),index_pc);
    C(isim,:) = crow(1:Nb);
end

%Normalize columns
Ccol_norm = (sqrt(sum(C.*C,1)))';
Wn = diag(1./Ccol_norm); %Normalization matrix 
Cn = C * Wn; %Column-normalized basis matrix

CorrM = Cn'*Cn;

figure;
imagesc(CorrM);
title('Correlation matrix')
colormap(jet);
colorbar;

cond(C)
cond(Cn)

[U,S,V] = svd(C);

figure;
subplot(1,2,1)
semilogy(diag(S),'ro','MarkerFaceColor',[1,0,0]);
% hold on
% semilogy([0 Nb],[tol tol],'k');
title('Singular values of C');
axis('square')

%ix gives the column number of all independent columns of the matrix Cn
%Each column of the matrix P gives the linear dependencies of the columns
%of Cn in terms of the independent columns given in ix

% [P,ix,k] = matrixIDvR(Cn,Nb);
[P,ix] = matrixID(Cn,1e-12);


norm(Cn(:,ix)*P-Cn)/norm(Cn)

LDn = zeros(Nb);
LDn(ix,:) = P;
LD = LDn.*(1./Ccol_norm).*Ccol_norm';

subplot(1,2,2)
imagesc(LD);
title('Linear dependence matrix')
colormap(jet);
colorbar;
axis('square')
pause
close

figure
%Constraint 1
subplot(1,3,1)
plot3(xData(:,1),xData(:,2),xData(:,3),'k');
hold on;
c1 = @(x,y,z) 0.5*x.^2 + 0.5*y.^2 - 1;
fimplicit3(c1,'EdgeColor','none','FaceAlpha',.5,'FaceColor','r')

%Constraint 2
subplot(1,3,2)
plot3(xData(:,1),xData(:,2),xData(:,3),'k');
hold on;
c2 = @(x,y,z) 2/3*x.^2 + 1/3*y.^2 - z.^2;
fimplicit3(c2,'EdgeColor','none','FaceAlpha',.5,'FaceColor','r')

%Constraint intersection
subplot(1,3,3)
plot3(xData(:,1),xData(:,2),xData(:,3),'k');
hold on;
fimplicit3(c1,'EdgeColor','none','FaceAlpha',.5,'FaceColor','r')
fimplicit3(c2,'EdgeColor','none','FaceAlpha',.5,'FaceColor','g')

%Constraints from nullspace
cvect = [1,5,7,10];
Ccntr = C(:,cvect);
eta = null(Ccntr);

figure
plot3(xData(:,1),xData(:,2),xData(:,3),'k');
hold on;
cns1 = @(x,y,z) eta(1,1) + eta(2,1)*x.^2 + eta(3,1)*y.^2 + eta(4,1)*z.^2;
cns2 = @(x,y,z) eta(1,2) + eta(2,2)*x.^2 + eta(3,2)*y.^2 + eta(4,2)*z.^2;

fimplicit3(cns1,'EdgeColor','none','FaceAlpha',.5,'FaceColor','r')
fimplicit3(cns2,'EdgeColor','none','FaceAlpha',.5,'FaceColor','g')
