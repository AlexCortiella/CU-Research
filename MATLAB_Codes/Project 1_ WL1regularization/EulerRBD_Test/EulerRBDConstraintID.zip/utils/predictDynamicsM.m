function [dx] = predictDynamicsM(t,x,Xi,index_pc)

C = piset_monomial(x',index_pc);

dx = (C'*Xi)';

end

