function [D_M,D_L] = build_dictionary(X,index_pc)
   
    m = size(X,1);
    P = size(index_pc,1);
    D_L = ones(m,P);
    D_M = D_L;

    n = size(X,2);
    
    
    for l = 1:size(X,1)
         if n > 1
            D_L(l,:) = piset(X(l,:),index_pc);
         else
            D_L(l,:) = piset(X(l),index_pc)';
         end
    end

    index_pc = index_pc'; 
    if n > 1
        for j = 1:P
            for i = 1:n
                   D_M(:,j) = D_M(:,j).*X(:,i).^(index_pc(i,j)); 
            end
        end
    else
       for i = 1:m
           D_M(i,:) = X(i).^index_pc;
       end
    end

   

end
