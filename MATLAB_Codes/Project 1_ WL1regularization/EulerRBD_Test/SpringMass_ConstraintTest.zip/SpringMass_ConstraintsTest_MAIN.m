%% Solve 1 dof linear/quadratic undamped, unforced, oscillator problem
clc;
close all;
clear all;
addpath('./utils','./Solvers')
rng(100);

%% Dynamical system parameters
%System parameters (Principal moments of inertia)
mass=1;
stiff=10;
alpha = 0.5*stiff;
beta = 0.5*mass;

param = [alpha;beta];
n = 3; %# state variables;

%Number of samples after trimming the ends
m = 100; %Number of samples after trimming

%Time parameters
dt = 0.001;
t0 = 0;
tf = 20;

%Intial conditions
x0 = [1;0;2];

%Kinetic energy (conserved in torque-free motion)
T = alpha*x0(1)^2 + beta*x0(2)^2
% time_anim = linspace(0,100,1000);
% poinsot_construction([I1,I2,I3],w0',time_anim,1)
% 
% pause
tspanf = t0:dt:(tf-dt);

%State sapace model of a 2nd order linear differential equation
options = odeset('RelTol',1e-10,'AbsTol',1e-10*ones(1,n));
[xf] = ode5(@(t,x) LinearTest(t,x,param),tspanf,x0');
x = xf;
t = tspanf';

%Verify that the states satisfy physical constraints
Tver = alpha*x(:,1).^2 + beta*x(:,2).^2;

figure;
plot(t,Tver,'r');
xlabel('Time')
legend('Kinetic energy')
pause
close

%% Sample dynamical system
dsample = length(t)/m;
timeData = t(1:dsample:end);
Nsamples = length(timeData);

%% True state variables
xtrue = x(1:dsample:end,1:3);
xDataT = [xtrue];

%% Original basis
d = 2;%polynomial order 
Nb = nchoosek(d+n,n);
index_pc = nD_polynomial_array(n,d);

% True coefficient vector in monomial basis
XiT = zeros(Nb,n);

XiT(3,1) = -beta;
XiT(2,2) = alpha;

C = zeros(Nsamples,Nb);
for isim = 1:Nsamples
    crow = piset_monomial(xDataT(isim,:),index_pc);
    C(isim,:) = crow(1:Nb);
end

%Normalize columns
Ccol_norm = (sqrt(sum(C.*C,1)))';
Wn = diag(1./Ccol_norm); %Normalization matrix 
Cn = C * Wn; %Column-normalized basis matrix

CorrM = Cn'*Cn;

figure;
imagesc(CorrM);
title('Correlation matrix')
colormap(jet);
colorbar;

cond(C)
cond(Cn)

[U,S,V] = svd(C);

figure;
subplot(1,2,1)
semilogy(diag(S),'ro','MarkerFaceColor',[1,0,0]);
title('Singular values of C');
axis('square')

%ix gives the column number of all independent columns of the matrix Cn
%Each column of the matrix P gives the linear dependencies of the columns
%of Cn in terms of the independent columns given in ix
[P,ix] = matrixID(Cn,10^-12);

norm(Cn(:,ix)*P-Cn)/norm(Cn)

LDn = zeros(Nb);
LDn(ix,:) = P;
LD=LDn.*(1./Ccol_norm).*Ccol_norm';

subplot(1,2,2)
imagesc(LD);
title('Linear dependence matrix')
colormap(jet);
colorbar;
axis('square')
pause
close

figure;
c1 = @(x,y,z) -1 + 1*x.^2 + 0.1*y.^2;%Cylinder
c2 = @(x,y,z) -z + 2*x.^2 + 0.2*y.^2;%Paraboloid
c3 = @(x,y,z) -z^2 + 4*x.^2 + 0.4*y.^2;%Hyperboloid
c4 = @(x,y,z) -x.*z + 2*x;%Plane z = 2
c5 = @(x,y,z) -y.*z + 2*y;%Plane z = 2

fimplicit3(c1,'EdgeColor','none','FaceAlpha',.5,'FaceColor','r');
hold on;
fimplicit3(c2,'EdgeColor','none','FaceAlpha',.5,'FaceColor','g');
fimplicit3(c3,'EdgeColor','none','FaceAlpha',.5,'FaceColor','b');
fimplicit3(c4,'EdgeColor','none','FaceAlpha',.5,'FaceColor','m');
fimplicit3(c5,'EdgeColor','none','FaceAlpha',.5,'FaceColor','c');

plot3(xDataT(:,1),xDataT(:,2),xDataT(:,3),'k')
axis('square')

