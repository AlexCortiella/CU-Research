function dxdt = EulerDynamics_w(t,x,param)

%Extract parameters
Ip = diag(param(1:3));

%Extract dynamic and kinematic states
w = zeros(3,1);
w(:,1) = x(1:3);%Angular velocity vector [w1;w2;w3]
%Time derivative (angular acceleration)

%Rotational dynamics
dwdt = Ip\( - cross(w,Ip*w));

%Time derivative of the state vector
dxdt = [dwdt;0;0];

end

