function dxdt = LinearTest(t,x,param)

%Extract parameters
alpha = param(1);
beta = param(2);

%Time derivative of the state vector
dxdt = [-beta*x(2); alpha*x(1); 0];

end

