clc;
close all;
clear all;
addpath('./utils','./Solvers')

%% Constraints
%% Sphere
%radius
R = 1;
%Center
xs0 = 0; ys0 = 0; zs0 = 0;
[xs,ys,zs] = sphere;
xs = R*(xs - xs0);
ys = R*(ys - ys0);
zs = R*(zs - zs0);

%% Plane
%Point
xp0 = 0; yp0 = 0; zp0 = 0;
%Normal
nx = 1; ny = 1; nz = 1;
[xp, yp] = meshgrid(-1:0.1:1); % Generate x and y data

A = nx; B = ny; C = nz; D = -A*xp0 - B*yp0 - C*zp0;
zp = -1/C*(A*xp + B*yp + D); % Solve for z data
%Trajectory
t = 0:0.01:3*(2*pi);
m = length(t);
rho = (A*xs0 + B*ys0 + C*zs0 - D)/(sqrt(A^2 + B^2 + C^2));
r = sqrt(R^2 - rho^2);
cx = xs0 + rho*A/(sqrt(A^2 + B^2 + C^2));
cy = ys0 + rho*B/(sqrt(A^2 + B^2 + C^2));
cz = zs0 + rho*C/(sqrt(A^2 + B^2 + C^2));

xpr = rand;
ypr = rand;
zpr = -1/C*(A*xpr + B*ypr + D);

khat = [nx,ny,nz]/norm([nx,ny,nz]);
jhat = [xpr - cx, ypr - cy, zpr - cz]/norm([xpr - cx, ypr - cy, zpr - cz]);
ihat = cross(jhat, khat);

x = cx + r*(cos(t)*ihat(1) + sin(t)*jhat(1));
y = cy + r*(cos(t)*ihat(2) + sin(t)*jhat(2));
z = cz + r*(cos(t)*ihat(3) + sin(t)*jhat(3));
xData = [x',y',z'];

plot3(x,y,z,'r','LineWidth',3)
hold on
surf(xs,ys,zs,'Facealpha',0.5,'EdgeColor','none','FaceColor','green') %Plot the surface
surf(xp,yp,zp,'Facealpha',0.5,'EdgeColor','none','FaceColor','blue') %Plot the surface
quiver3(cx,cy,cz,2*R*ihat(1),2*R*ihat(2),2*R*ihat(3),'k')
quiver3(cx,cy,cz,2*R*jhat(1),2*R*jhat(2),2*R*jhat(3),'k')
quiver3(cx,cy,cz,2*R*khat(1),2*R*khat(2),2*R*khat(3),'k')
axis('equal')

%Randomize values of the states
%% Original basis
p = 2;%polynomial order 
n = 3;
Nb = nchoosek(p+n,n);
index_pc = nD_polynomial_array(n,p);
C = zeros(m,Nb);
for isim = 1:m
    crow = piset_monomial(xData(isim,:),index_pc);
    C(isim,:) = crow(1:Nb);
end

% Find rank of Caug
fprintf('Rank of C')
rank(C)
pause

%Normalize columns
Ccol_norm = (sqrt(sum(C.*C,1)))';
Wn = diag(1./Ccol_norm); %Normalization matrix 
Cn = C * Wn; %Column-normalized basis matrix

CorrM = Cn'*Cn;

figure;
imagesc(CorrM);
title('Correlation matrix')
colormap(jet);
colorbar;

[U,S,V] = svd(C);

figure;
semilogy(diag(S),'ro','MarkerFaceColor',[1,0,0]);
title('Singular values of C');
axis('square')

%ix gives the column number of all independent columns of the matrix Cn
%Each column of the matrix P gives the linear dependencies of the columns
%of Cn in terms of the independent columns given in ix
[P,ix] = matrixID(Cn,10^-12);

norm(Cn(:,ix)*P-Cn)/norm(Cn);

LDn = zeros(Nb);
LDn(ix,:) = P;
LD = LDn.*(1./Ccol_norm).*Ccol_norm';
LD
figure
imagesc(LD);
title('Linear dependence matrix')
colormap(jet);
colorbar;
axis('square')
pause
close

remove_basis = setdiff(1:Nb,ix);
CM = C;
CM(:,remove_basis) = [];

fprintf('Condition number of C')
cond(C)
fprintf('Condition number of CM')
cond(CM)
