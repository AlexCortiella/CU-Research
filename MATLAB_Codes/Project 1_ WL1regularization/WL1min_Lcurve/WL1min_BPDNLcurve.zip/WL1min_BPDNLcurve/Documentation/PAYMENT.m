% PAYMENT -- No Charge for SparseLab Software
%
%  SparseLab software is available at NO CHARGE 
%	by www access from http://www-stat.stanford.edu/~sparselab
%
%  The software is copyrighted. For permissions to copy, see
%  the file COPYING.m or e-mail SparseLab@stat.stanford.edu
%
%  If you use this software to produce scientific articles, we
%  would appreciate being informed of the article's title, authors,
%  topic, and place of appearance.
%
%  If this software played a major enabling role in your scientific work,
%  and you are so moved, you might acknowedge us in your article. 
% 
help('PAYMENT')

%
% Copyright (c) 2006. Victoria Stodden and David Donoho
% 

%
% Part of SparseLab Version:100
% Created Tuesday March 28, 2006
% This is Copyrighted Material
% For Copying permissions see COPYING.m
% Comments? e-mail sparselab@stanford.edu
%
