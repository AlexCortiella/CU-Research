% SparseLab shell_tools Directory, Version 100
%
% This directory houses build shell scripts.
%
%              files in this directory
%
%   append_footer.sh           -    adds a footer to all non-Contents
%                                   SparseLab .m files
%   SparseLab_Footer.txt       -    the footer that gets added
%

%
% Copyright (c) 2007. Victoria Stodden
%  

%
% Part of SparseLab Version:200
% Created Tuesday March 24, 2007
% This is Copyrighted Material
% For Copying permissions see COPYING.m
% Comments? e-mail sparselab@stanford.edu
%