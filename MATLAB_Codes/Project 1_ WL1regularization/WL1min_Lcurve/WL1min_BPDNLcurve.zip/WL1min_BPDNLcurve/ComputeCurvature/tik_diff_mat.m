% Author: Paul Diaz 2018
% 2nd order Tikhonov regularization see METHODS FOR NUMERICAL
% DIFFERENTIATION OF NOISY DATA by IAN KNOWLES, ROBERT J. RENKA 2014
% Inputs: 
% x - Nx1 vector of noisy state information
% T - Nx1 vector of time-step information
% lambda - regularization parameter (a knob for tuning)
% Outputs:
% dx - Nx1 gradient approximations on the MIDPOINTS of T 

function [A,Dt] = tik_diff_mat(T)

[A,n,dt] = diff_mat(T);

D2 = full(gallery('tridiag',n,-1,2,-1))/(dt^2);
D1 = full(gallery('tridiag',n,0,-1,1))/dt;
%D1(end,end-1) = 1;
Dt = D1'*D2';

end


function [A,n,dt] = diff_mat(T)
n = length(T);
dt = T(2)-T(1);
a = T(1);
b = T(end);
A = zeros(n);
t = zeros(n,1);

for j = 1:n+1
    t(j) = a +(j-1)*dt;
end

for j = 1:n
    for i = 1:n
        if T(i) <= t(j)
            A(i,j) = 0;
        end
        if (t(j) < T(i)) && ( T(i)  < t(j+1))
           A(i,j) = T(i)-t(j); 
        end
        if t(j+1) <= T(i)
           A(i,j) = dt; 
        end
        
    end
    
end
end
