%% Generate Error, cross-validation and Lcurve plots
clc;
close all;
clear all;

filename = 'WLmin_ErrorConv_Lorenz63_q3_Noise001';
load(filename)

Ndofs = size(coefferr,2);
Niter = size(coefferr,1);

Ydata = zeros(Niter,Ndofs);
for d = 1:Ndofs
    Ydata(:,d) = coefferr(1:Niter,d);
end
Xdata = 0:1:Niter-1;

createErrorConvergencePlots(Xdata, Ydata)
print(filename,'-depsc')