%% Generate Error, cross-validation and Lcurve plots
clc;
close all;
clear all;

filename = 'WL1min_Lorenz63_0thIteration_Lcurve_3dof_Noise001';
load(filename)


Ydata = [sol_err;sol_l1_norm;tr_err];

createErrorPlots(sigmas, Ydata)
print(filename,'-depsc')