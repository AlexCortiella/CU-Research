%% Generate cross-validation plots
clc;
close all;
clear all;

filename1 = 'WL1min_Lorenz63_0thIteration_Lcurve_3dof_Noise001';
load(filename1)
filename2 = 'WL1min_Lorenz63_Xval_0thIteration_3dof_Noise001';
load(filename2)

Ydata = [sol_err;mean_errZ];

createXvalPlots(sigmas, Ydata)
print(filename2,'-depsc')