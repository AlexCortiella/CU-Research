%% Generate Error, cross-validation and Lcurve plots
clc;
close all;
clear all;

filename1 = 'WL1min_Lorenz63_0thIteration_Lcurve_3dof_Noise001';
load(filename1)

Ydata = [sigmas;sol_err;sol_l1_norm;tr_err];
YdataC = [sol_errC;sol_l1_normC;tr_errC];%Corner values

createLcurvePlots(sigmas, Ydata, YdataC)
print(filename1,'-depsc')