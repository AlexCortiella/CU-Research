function [k_reg,k_polygon] = ComputeCurvature(xDataO,yDataO)

%Make x axis evenly spaced
minx = min(xDataO);
maxx = max(xDataO);
xData = (minx:0.0001:maxx)';
yData = interp1(xDataO,yDataO,xData);
% figure(1)
% plot(xData,yData,'r.');
% pause
% close
%Tikhonov Differentiation method
%% 2) TIKHONOV REGULARIZATION
        
    %Vector of ordinates
    xvec = xData;
    xvecm = 0.5*(xvec(1:end-1) + xvec(2:end));
    
    %Generate integral and regularization matrices ( C(x) = |Ax - y| + l*|Lx|)
    [A,L] = tik_diff_mat(xvec);

    %Variables to perform cross validation on l
    [U,sm,X,V,W] = cgsvd(A,L);
    
    %Compute first derivative
    b = yData - yData(1);
    [reg_min,G,reg_param] = gcv(U,sm,b,'Tikh');
    [dyFm,res1] = tik_diff(yData,xvec,reg_min);
    dyData = pchip(xvecm,dyFm(1:end-1),xvec);
%     figure
%     plot(dyData);
%     pause
%     close
    %Compute second derivative
    b = dyData - dyData(1);
    [reg_min,G,reg_param] = gcv(U,sm,b,'Tikh');
    [ddyFm,res1] = tik_diff(dyData,xvec,reg_min);
    ddyData = pchip(xvecm,ddyFm(1:end-1),xvec);
%     figure
%     plot(ddyData);
%     pause
%     close
    %Compute curvature
    
    k_reg = abs(ddyData)./((1 + dyData.^2).^(3/2));
    maxk_reg = find(k_reg == max(k_reg));
    
    %% 2) POLYGON FIT CURVATURE
    k_polygon = LineCurvature2D([xData yData]);
    maxk_pol= find(k_polygon == max(k_polygon));

end

