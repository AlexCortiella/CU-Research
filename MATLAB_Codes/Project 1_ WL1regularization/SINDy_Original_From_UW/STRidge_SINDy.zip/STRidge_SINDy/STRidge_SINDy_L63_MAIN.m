clear all, close all, clc
addpath('./utils','./DataFiles');

%Load data
load('DataLorenz63DiffValAWGN.mat')
load('DataLorenz63DiffTrAWGN.mat')

%Setup
Nsamples_total = size(xDataNTr,1);
Ndofs = size(xDataNTr,2);
maxit = 100;
coefferr = zeros(1,Ndofs);


%Basis parameters
polyorder = 3;
usesine = 0;

% %Training and validation sets
% Ntr = 300;
% Nval = 4*Ntr;
% 
% %% Training data
% ytr = dxDataN(1:Ntr,:);
% xtr = xDataN(1:Ntr,:);
% %pool Data  (i.e., build library of nonlinear time series)
% Xtr = poolData(xtr,Ndofs,polyorder,usesine);
% Nbasis = size(Xtr,2);
% 
% %% Validation data
% yval = dxDataN(Ntr+1:Nval+Ntr,:);
% xval = xDataN(Ntr+1:Nval+Ntr,:);
% %pool Data  (i.e., build library of nonlinear time series)
% Xval = poolData(xval,Ndofs,polyorder,usesine);

%% Training data
ytr = dxDataNTr;
xtr = xDataNTr;
%pool Data  (i.e., build library of nonlinear time series)
Xtr = poolData(xtr,Ndofs,polyorder,usesine);
Nbasis = size(Xtr,2);

%% Validation data
yval = dxDataNVal;
xval = xDataNVal;
%pool Data  (i.e., build library of nonlinear time series)
Xval = poolData(xval,Ndofs,polyorder,usesine);

% True coefficient vector in monomial basis
sigma = 10;  % Lorenz's parameters (chaotic)
beta = 8/3;
rho = 28;

XiT = zeros(Nbasis,Ndofs);
XiT(2,1) = -sigma;
XiT(2,2) = rho;
XiT(3,1) = sigma;
XiT(3,2) = -1;
XiT(4,3) = -beta;
XiT(6,3) = 1;
XiT(7,2) = -1;

%% Sequential Thresholded Ridge Regression
normalize = 2;
dtol = 0.1;
tol_iters = 10000;
[Xi_STR] = TrainSTRidgeTrVal(Xtr,ytr,Xval,yval,maxit,dtol,tol_iters,normalize);

for d = 1:Ndofs
coefferr(d) = norm(Xi_STR(:,d) - XiT(:,d))/norm(XiT(:,d));
end

coefferr
