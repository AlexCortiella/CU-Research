function [Xi_STR] = TrainSTRidgeTrVal(Xtr,ytr,Xval,yval,maxit,dtol,tol_iters,normalize)

%This code was implemented from Algorithm 2 of:
%S. Rudy, J. L. Proctor, S. L. Brunton, and J. N. Kutz Data-driven discovery of partial differential equations, arxiv (2016)

%Parameters
Ndofs = size(ytr,2);
Nbasis = size(Xtr,2);
Xi_STR = zeros(Nbasis,Ndofs);

%Set an appropriate l0-penalty. The following worked well empirically
lambda = 0.001*cond([Xtr;Xval]);
% lambda = 0.001*cond(Xval);

for d = 1:Ndofs
    
    ytrd = ytr(:,d);
    yvald = yval(:,d);
    
    %Get a baseline predictor(Ordinary Least Squares)
    Xibest = Xtr\ytrd;
    Xi_l0 = length(find(Xibest));
    errorbest = norm(Xval*Xibest - yvald)^2 + lambda*Xi_l0;
    tol_best = 0;
    
    %Now search through values of tolerance to find the best predictor
    tol = dtol;
    
        for itr = 1:tol_iters
    
        %Train and evaluate performance
        Xi = STRidge(Xtr,ytrd,lambda,maxit,tol,normalize)
        Xi_l0 = length(find(Xi));
        error = norm(Xval*Xi - yvald) + lambda*Xi_l0;

        %Is the error still dropping?
        if (error <= errorbest)
            errorbest = error;
            Xibest = Xi;
            tol_best = tol;
            tol = tol + dtol;
        else
            tol = max([0,tol-2*dtol]);
            dtol = 2*dtol/(tol_iters - itr);
            tol = tol + dtol;
            
        end
        
        end
        
        display(['Optimal tolerance: ',num2str(tol_best)]);
        
        Xi_STR(:,d) = Xibest
        
end

end

