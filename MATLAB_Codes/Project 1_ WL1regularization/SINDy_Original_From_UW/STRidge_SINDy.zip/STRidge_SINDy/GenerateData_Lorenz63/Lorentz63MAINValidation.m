%% Solve 1 dof linear/quadratic undamped, unforced, oscillator problem
clc;
close all;
clear all;
%% Model problem d^2(q)/dt^2 + k/m dq/dt = f(t)

%System parameters
sigma = 10;
rho = 28;
beta = 8/3;
param = [sigma,rho,beta];
n = 3; %# state variables;

%Time parameters
dt = 0.0001;
t0 = 0;
tf = 5;

%Sampling rate
sampleTime = 0.01;
Nsamples = tf/(dt/sampleTime) + 1;

%Intial conditions
Nval = 100;
XValData = zeros(Nsamples,n,Nval);
XValICData = zeros(Nval,n);
timeValData = zeros(Nsamples,1);

x0val = 10.^(-1 + (3+1)*rand(n,Nval));%Same mdodel as SINDy-AIC paper

%Generate data for each validation set
for v = 1:Nval
    v
    x0 = x0val(:,v);    
    tspanf = t0:dt:tf;
    Nmeas = length(tspanf);

    %State sapace model of a 2nd order linear differential equation
    options = odeset('RelTol',1e-10,'AbsTol',1e-10*ones(1,n));
    [xf] = ode5(@(t,x) LorentzSys63(t,x,param),tspanf,x0);
    x = xf;
    t = tspanf';


    x1true = x(:,1);
    x2true = x(:,2);
    x3true = x(:,3);

    xDataT = [x1true,x2true,x3true];

    dx1true = sigma*(x2true-x1true);
    dx2true = x1true.*(rho - x3true) - x2true;
    dx3true = x1true.*x2true - beta*x3true;

    dxDataT = [dx1true,dx2true,dx3true];

    %Add Gaussian white noise to data;
    etax = 0.01;
    etadx = 0.01;

    % X1 state
    x1noisy = x1true.*(1+etax*randn(Nmeas,1));
    % X2 state
    x2noisy = x2true.*(1+etax*randn(Nmeas,1));
    % X3 state
    x3noisy = x3true.*(1+etax*randn(Nmeas,1));

    xDataN = [x1noisy,x2noisy,x3noisy];


    % dX1 state
    dx1noisy = dx1true.*(1+etadx*randn(Nmeas,1));
    % dX2 state
    dx2noisy = dx2true.*(1+etadx*randn(Nmeas,1));
    % dX3 state
    dx3noisy = dx3true.*(1+etadx*randn(Nmeas,1));

    dxDataN = [dx1noisy,dx2noisy,dx3noisy];

    timeData = t;


    %% Store data
    % sampleTime = 0.01;
   

    dsample = sampleTime/dt;
    timeData = timeData(1:dsample:end);

    xDataT = xDataT(1:dsample:end,:);
    dxDataT = dxDataT(1:dsample:end,:);
    xDataN = xDataN(1:dsample:end,:);
    dxDataN = dxDataN(1:dsample:end,:);
    
    timeValData = timeData;
    XValData(:,:,v) = xDataN;
    XValICData(v,:) = x0';
    
    
end

save('ValidationSetL63_SINDY_AIC','XValData','XValICData','timeValData')