%% Solve 1 dof linear/quadratic undamped, unforced, oscillator problem
clc;
close all;
clear all;
rng(100);
%% Model problem d^2(q)/dt^2 + k/m dq/dt = f(t)

%System parameters
sigma = 10;
rho = 28;
beta = 8/3;
param = [sigma,rho,beta];
n = 3; %# state variables;

%Time parameters
dt = 0.0001;
t0 = 0;
tf = 5*3.5;

%Intial conditions
x0 = [-8;7;27];

tspanf = t0:dt:tf;
Nmeas = length(tspanf);

%State sapace model of a 2nd order linear differential equation
options = odeset('RelTol',1e-10,'AbsTol',1e-10*ones(1,n));
[xf] = ode5(@(t,x) LorentzSys63(t,x,param),tspanf,x0');
x = xf;
t = tspanf';


x1true = x(:,1);
x2true = x(:,2);
x3true = x(:,3);

xDataT = [x1true,x2true,x3true];

dx1true = sigma*(x2true-x1true);
dx2true = x1true.*(rho - x3true) - x2true;
dx3true = x1true.*x2true - beta*x3true;

dxDataT = [dx1true,dx2true,dx3true];

%Add Gaussian white noise to data;
etax = 0.01;
etadx = 0.01;

% X1 state
x1noisy = x1true.*(1+etax*randn(Nmeas,1));
% X2 state
x2noisy = x2true.*(1+etax*randn(Nmeas,1));
% X3 state
x3noisy = x3true.*(1+etax*randn(Nmeas,1));

xDataN = [x1noisy,x2noisy,x3noisy];


% dX1 state
dx1noisy = dx1true.*(1+etadx*randn(Nmeas,1));
% dX2 state
dx2noisy = dx2true.*(1+etadx*randn(Nmeas,1));
% dX3 state
dx3noisy = dx3true.*(1+etadx*randn(Nmeas,1));

dxDataN = [dx1noisy,dx2noisy,dx3noisy];

timeData = t;

%% Plot data (true vs noisy states)
figure;
subplot(3,1,1)
plot(t,x1noisy,'r.',t,x1true,'k')
xlabel('Time');
ylabel('Solution x1(t)');
legend('Noisy x_1','True x_1')

subplot(3,1,2)
plot(t,x2noisy,'r.',t,x2true,'k')
xlabel('Time');
ylabel('Solution x2(t)');
legend('Noisy x_2','True x_2')

subplot(3,1,3)
plot(t,x3noisy,'r.',t,x3true,'k')
xlabel('Time');
ylabel('Solution x3(t)');
legend('Noisy x_3','True x_3')

%% Plot dxdata (true vs noisy states)
figure;
subplot(3,1,1)
plot(t,dx1noisy,'r.',t,dx1true,'k')
xlabel('Time');
ylabel('dx1dt');
legend('Noisy x_1','True x_1')

subplot(3,1,2)
plot(t,dx2noisy,'r.',t,dx2true,'k')
xlabel('Time');
ylabel('dx2dt');
legend('Noisy x_2','True x_2')

subplot(3,1,3)
plot(t,dx3noisy,'r.',t,dx3true,'k')
xlabel('Time');
ylabel('dx3dt');
legend('Noisy x_3','True x_3')

%% Plot 3D phase space (true vs noisy states)

figure;
suptitle('Simulation of Lorentz system 63')
subplot1 = subplot(1,2,1)
plot3(x1true,x2true,x3true,'r')
xlabel('X')
ylabel('Y')
zlabel('Z')
legend('True')
grid('on')
axis('equal')
axis('tight')
view([-150.3 19.6]);
% Create zlabel
zlabel('Z','FontWeight','bold','FontSize',18);
% Create ylabel
ylabel('Y','FontWeight','bold','FontSize',18);
% Create xlabel
xlabel('X','FontWeight','bold','FontSize',18);
set(subplot1,'DataAspectRatio',[1 1 1],'FontSize',14);

subplot2 = subplot(1,2,2)
plot3(x1noisy,x2noisy,x3noisy,'k.')
xlabel('X')
ylabel('Y')
zlabel('Z')
legend('Noisy')
grid('on')
axis('equal')
axis('tight')
view([-150.3 19.6]);
% Create zlabel
zlabel('Z','FontWeight','bold','FontSize',18);
% Create ylabel
ylabel('Y','FontWeight','bold','FontSize',18);
% Create xlabel
xlabel('X','FontWeight','bold','FontSize',18);
set(subplot2,'DataAspectRatio',[1 1 1],'FontSize',14);



%% Plot 2D phase space (true vs noisy states)

figure;
suptitle('Simulation of Lorentz system 63')
subplot(3,1,1);
plot(x1true,x2true,'r')
xlabel('X')
ylabel('Y')
grid('on')
axis('equal')

subplot(3,1,2);
plot(x1true,x3true,'g')
xlabel('X')
ylabel('Z')
grid('on')
axis('equal')

subplot(3,1,3);
plot(x2true,x3true,'b')
xlabel('Y')
ylabel('Z')
grid('on')
axis('equal')


%% Store data
% sampleTime = 0.01;
sampleTime = 0.01;

dsample = sampleTime/dt;
timeData = timeData(1:dsample:end);

xDataT = xDataT(1:dsample:end,:);
dxDataT = dxDataT(1:dsample:end,:);
xDataN = xDataN(1:dsample:end,:);
dxDataN = dxDataN(1:dsample:end,:);

save('DataLorentz63.mat','xDataT','dxDataT','xDataN','dxDataN','timeData')
% save('DataLorentz63Val.mat','xDataT','xDataN','timeData')

% 
