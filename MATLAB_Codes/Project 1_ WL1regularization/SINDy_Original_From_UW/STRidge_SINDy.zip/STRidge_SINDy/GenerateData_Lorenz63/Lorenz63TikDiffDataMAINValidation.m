%% SPARSE IDENTIFICATION OF NONLINEAR DYNAMICAL SYSTEMS

clear all, close all, clc
addpath('./utils','spgl1-1.9','regtools');

%% Load data
% load('DataLorentz630001.mat');
load('ValidationSet_SINDY_AIC.mat');
XValICDataL63 = XValICData;
%Loop over all validation sets
Nval = size(XValData,3);

for v = 1:Nval
v    
xDataN = XValData(:,:,v);
tData = timeValData;

%Gather data
Nsamp_total = size(xDataN,1);
n = size(xDataN,2);

%Noisy data
xDataN = xDataN(1:Nsamp_total,:);
dxDataN = zeros(Nsamp_total,n);

%Tikhonov Differentiation method
%% 2) TIKHONOV REGULARIZATION
        
    %Vector of ordinates
    tvec = tData;
    tvecm = 0.5*(tvec(1:end-1) + tvec(2:end));
    
    %Generate integral and regularization matrices ( C(x) = |Ax - y| + l*|Lx|)
    [A,L] = tik_diff_mat(tvec);

    %Variables to perform cross validation on l
    [U,sm,X,V,W] = cgsvd(A,L);
    
    for d = 1:n
        b = xDataN(:,d) - xDataN(1,d);
        [reg_min,G,reg_param] = gcv(U,sm,b,'Tikh');
        [dxFm,res1] = tik_diff(xDataN(:,d),tvec,reg_min);
        dxDataN(:,d) = pchip(tvecm,dxFm(1:end-1),tvec);
    end
    
    samptrim = floor(0.1*Nsamp_total/2);
    xDataN = xDataN(samptrim+1:end-samptrim,:);
    dxDataN = dxDataN(samptrim+1:end-samptrim,:);
    tData = tData(samptrim+1:end-samptrim);
    
    dXValDataL63(:,:,v) = dxDataN;
    XValDataL63(:,:,v) = xDataN;
    timeValDataL63 = tData;
    
end



save('ValidationSetL63_SINDY_AIC_Diff.mat','dXValDataL63','XValDataL63','XValICDataL63','timeValDataL63')
