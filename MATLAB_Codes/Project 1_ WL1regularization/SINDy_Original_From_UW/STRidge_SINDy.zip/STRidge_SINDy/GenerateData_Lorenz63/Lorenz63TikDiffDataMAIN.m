%% SPARSE IDENTIFICATION OF NONLINEAR DYNAMICAL SYSTEMS

clear all, close all, clc
addpath('./utils','spgl1-1.9','regtools');

%% Load data
% load('DataLorentz630001.mat');
load('DataLorentz63.mat');


%Gather data
Nsamp_total = size(xDataN,1);
n = size(xDataT,2);

%True data
xDataT = xDataT(1:Nsamp_total,:);
dxDataT = dxDataT(1:Nsamp_total,:);
tDataT = timeData(1:Nsamp_total,:);
dtDataT = mean(tDataT(2:end) - tDataT(1:end-1));

%Noisy data
xDataN = xDataN(1:Nsamp_total,:);
dxDataN = zeros(Nsamp_total,n);

%Tikhonov Differentiation method
%% 2) TIKHONOV REGULARIZATION
        
    %Vector of ordinates
    tvec = tDataT;
    tvecm = 0.5*(tvec(1:end-1) + tvec(2:end));
    
    %Generate integral and regularization matrices ( C(x) = |Ax - y| + l*|Lx|)
    [A,L] = tik_diff_mat(tvec);

    %Variables to perform cross validation on l
    [U,sm,X,V,W] = cgsvd(A,L);
    
    for d = 1:n
        b = xDataN(:,d) - xDataN(1,d);
        [reg_min,G,reg_param] = gcv(U,sm,b,'Tikh');
        [dxFm,res1] = tik_diff(xDataN(:,d),tvec,reg_min);
        dxDataN(:,d) = pchip(tvecm,dxFm(1:end-1),tvec);
        pause
    end

%% PLOTS

figure(1);
subplot(3,1,1);
plot(tDataT, xDataN(:,1),'r.')
hold on
plot(tDataT, xDataT(:,1),'k')


subplot(3,1,2);
plot(tDataT, xDataN(:,2),'r.')
hold on
plot(tDataT, xDataT(:,2),'k')

subplot(3,1,3);
plot(tDataT, xDataN(:,3),'r.')
hold on
plot(tDataT, xDataT(:,3),'k')

figure(2);
subplot(3,1,1);
plot(tDataT, dxDataT(:,1),'k')
hold on
plot(tDataT, dxDataN(:,1),'r.')

subplot(3,1,2);
plot(tDataT, dxDataT(:,2),'k')
hold on
plot(tDataT, dxDataN(:,2),'r.')

subplot(3,1,3);
plot(tDataT, dxDataT(:,3),'k')
hold on
plot(tDataT, dxDataN(:,3),'r.')

samptrim = floor(0.1*Nsamp_total/2);
xDataN = xDataN(samptrim+1:end-samptrim,:);
dxDataN = dxDataN(samptrim+1:end-samptrim,:);
xDataT = xDataT(samptrim+1:end-samptrim,:);
dxDataT = dxDataT(samptrim+1:end-samptrim,:);
tData = tDataT(samptrim+1:end-samptrim);

figure;
subplot(3,1,1);
plot(tData, dxDataT(:,1),'k')
hold on
plot(tData, dxDataN(:,1),'r.')

subplot(3,1,2);
plot(tData, dxDataT(:,2),'k')
hold on
plot(tData, dxDataN(:,2),'r.')

subplot(3,1,3);
plot(tData, dxDataT(:,3),'k')
hold on
plot(tData, dxDataN(:,3),'r.')

mse1 = immse(dxDataT(:,1),dxDataN(:,1))
mse2 = immse(dxDataT(:,2),dxDataN(:,2))
mse3 = immse(dxDataT(:,3),dxDataN(:,3))

mean1 = mean(dxDataT(:,1)-dxDataN(:,1))
mean2 = mean(dxDataT(:,2)-dxDataN(:,2))
mean3 = mean(dxDataT(:,3)-dxDataN(:,3))

std1 = std(dxDataT(:,1)-dxDataN(:,1))
std2 = std(dxDataT(:,2)-dxDataN(:,2))
std3 = std(dxDataT(:,3)-dxDataN(:,3))

var1 = var(dxDataT(:,1)-dxDataN(:,1))
var2 = var(dxDataT(:,2)-dxDataN(:,2))
var3 = var(dxDataT(:,3)-dxDataN(:,3))

err1 = norm(dxDataT(:,1)-dxDataN(:,1))/norm(dxDataT(:,1))
err2 = norm(dxDataT(:,2)-dxDataN(:,2))/norm(dxDataT(:,2))
err3 = norm(dxDataT(:,3)-dxDataN(:,3))/norm(dxDataT(:,3))


figure
subplot(3,1,1);
histogram(dxDataN(:,1) - dxDataT(:,1))
subplot(3,1,2);
histogram(dxDataN(:,2) - dxDataT(:,2))
subplot(3,1,3);
histogram(dxDataN(:,3) - dxDataT(:,3))

save('DataLorentz63Diff.mat','xDataT','dxDataT','xDataN','dxDataN','tData')
