% Copyright 2015, All Rights Reserved
% Code by Steven L. Brunton
% For Paper, "Discovering Governing Equations from Data: 
%        Sparse Identification of Nonlinear Dynamical Systems"
% by S. L. Brunton, J. L. Proctor, and J. N. Kutz

% Note, for larger error terms, it helps to remove constant terms in
% "poolData"

clear all, close all, clc
figpath = '../figures/';
addpath('./utils');

%% generate Data
polyorder = 5;
usesine = 0;
sigma = 10;  % Lorenz's parameters (chaotic)
beta = 8/3;
rho = 28;
n = 3;
x0=[-8; 8; 27];  % Initial condition

% Integrate
dt = 0.001;
tspan=[dt:dt:1];
N = length(tspan);
options = odeset('RelTol',1e-12,'AbsTol',1e-12*ones(1,n));
[t,x]=ode45(@(t,x) lorenz(t,x,sigma,beta,rho),tspan,x0,options);
xclean = x;
% add noise
eps = .01;
x = x + eps*randn(size(x));
% compute clean derivative  (just for comparison!)
for i=1:length(x)
    dxclean(i,:) = lorenz(0,xclean(i,:),sigma,beta,rho);
end

%%  Total Variation Regularized Differentiation

lambda = 1;
dxt(:,1) = TVRegDiff( x(:,1), 10, lambda, [], 'small', 1e12, dt, 1, 1 );
hold on
plot(dxclean(:,1),'r')
% xlim([5000 7500])
figure
dxt(:,2) = TVRegDiff( x(:,2), 10, lambda, [], 'small', 1e12, dt, 1, 1 );
hold on
plot(dxclean(:,2),'r')
% xlim([5000 7500])
figure
dxt(:,3) = TVRegDiff( x(:,3), 10, lambda, [], 'small', 1e12, dt, 1, 1 );
hold on
plot(dxclean(:,3),'r')
% xlim([5000 7500])

xDataT = xclean;
dxDataT = dxclean;
xDataN = x;
dxDataN = dxt;
timeData = t;

figure
subplot(3,1,1);
plot(dxDataT(:,1),'r*');
hold on
plot(dxDataN(:,1),'k');

subplot(3,1,2);
plot(dxDataT(:,2),'r*');
hold on
plot(dxDataN(:,2),'k');

subplot(3,1,3);
plot(dxDataT(:,3),'r*');
hold on
plot(dxDataN(:,3),'k');


save('DataLorentz63.mat','xDataT','dxDataT','xDataN','dxDataN','timeData')