function [Xi_STR] = TrainSTRidge(X0,y,maxit,dtol,tol_iters,normalize)

%This code was implemented from Algorithm 2 of:
%S. Rudy, J. L. Proctor, S. L. Brunton, and J. N. Kutz Data-driven discovery of partial differential equations, arxiv (2016)

%Parameters
Ndofs = size(y,2);
Nbasis = size(X0,2);
Xi_STR = zeros(Nbasis,Ndofs);

%First split the data into training and testing sets
K = 5; %20/80 split
cvindx = crossvalind('Kfold',Nsamp_total,K);%Create indices

%Validation set
valid = (cvindx == k);
yval = y(valid,:);
Xval = X0(valid,:);
%Training set
train = ~valid;
ytr = y(train,:);
Xtr = X0(train,:);

%Set an appropriate l0-penalty. The following worked well empirically
lambda = 1e-3*cond(X0);

for d = 1:Ndofs
    
    ytrd = ytr(:,d);
    yvald = yval(:,d);
    
    %Get a baseline predictor(Ordinary Least Squares)
    Xibest = Xtr\ytrd;
    Xi_l0 = length(find(Xibest));
    errorbest = norm(Xval*Xibest - yvald)^2 + lambda*Xi_l0;
    
    %Now search through values of tolerance to find the best predictor
    tol = dtol;
    
        for itr = 1:tol_iters
    
        %Train and evaluate performance
        Xi = STRidge(Xtr,ytrd,lambda,maxit,tol,normalize);
        Xi_l0 = length(find(Xi));
        error = norm(Xval*Xi - yvald)^2 + lambda*Xi_l0;
        
        %Is the error still dropping?
        if (error <= errorbest)
            errorbest = error;
            Xibest = Xi;
            tol = tol + dtol;
        else
            tol = max([0,tol-2*dtol]);
            dtol = 2*dtol/(tol_iters - itr);
            tol = tol + dtol;
            
        end
        
        end
        
        Xi_STR(:,d) = Xibest;
        
end

end

