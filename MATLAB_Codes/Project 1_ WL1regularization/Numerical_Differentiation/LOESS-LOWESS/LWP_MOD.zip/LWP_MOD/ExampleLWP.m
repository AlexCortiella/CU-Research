clc;
close all;
clear all;

x = [-1:0.01:1]';
y = cos(10*x);
yn = y + 0.1*randn(length(y),1);

figure
plot(x,y,'g')
hold on
plot(x,yn,'r.')

%LOESS parameters
Wfun = 'TRC'; %weighting function
degree = 2;%polynomial degree

% Global polynomial
params = lwpparams(Wfun, degree, true, 1);
[MSE, df] = lwpeval(X, Y, params, 'CV');
plot(df, MSE, 'x', 'MarkerSize', 10, 'LineWidth', 2, 'Color', colors(i+1,:));
% Local polynomial
params = lwpparams('GAU', i, false);
[hBest, critBest, results] = ...
lwpfindh(X, Y, params, 'CV', 0:0.01:1, [], [], [], false, false);

