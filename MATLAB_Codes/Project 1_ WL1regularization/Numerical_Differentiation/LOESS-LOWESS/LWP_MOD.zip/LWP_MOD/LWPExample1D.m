clc;
close all;
clear all;


%% 1D Example

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Set up parameters
%Noise (zero-mean AWGN)
sigma = 0.1;
%LWP parameters
polyord = 2;
kernel = 'TRC';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


x0 = 0;
xf = 10;
dx = 0.001;
Nsamp = 100;
dxn = (xf-x0)/(Nsamp-1);
p1 = -0.1;
p2 = 1;
% funy = @(x) (exp(p1.*x).*cos(p2*x));
% fundy = @(x) (exp(p1.*x).*(p1*cos(p2*x) - p2*sin(p2*x)));
funy = @(x) (sin(x));
fundy = @(x) (cos(x));

x = (x0:dx:xf)';
xn = (x0:dxn:xf)';
rng(1);
y = funy(x);
dy = fundy(x);
yn = funy(xn);
ynoisy = yn + sigma*randn(Nsamp,1);

figure
plot(x,y,'b');
hold on
plot(xn,ynoisy,'k.');
title('Original signal vs Noisy signal')
xlabel('x')
ylabel('y = f(x)')
legend('Original', 'Noisy')

params = lwpparams(kernel, polyord, false); 
[hBest, critBest, results] = lwpfindh(xn, ynoisy, params, 'CV');

% The function prints its progress (you can turn it off by setting the verbose argument to false )
% and finally in its output we get the best found h ( hBest ), its corresponding criterion value
% ( critBest ), as well as results from each iteration of the Grid Search ( results ).
% Let's update our parameters with the hBest value and create a surface plot. For this we will need
% to predict response values for a range of different inputs. This is done using function lwppredict .

params = lwpparams(kernel, polyord, false, hBest);
xr = x;
% [yr] = lwppredict(xn, ynoisy, params, xr);
[yr,dyr] = lwppredictMOD(xn, ynoisy, params, xr);

figure;
plot(xn,ynoisy,'k.');
hold on
plot(x,y,'b');
plot(xr,yr,'r');
title('Reconstructed signal vs original signal')
xlabel('x')
ylabel('y = f(x)')
legend('Noisy','Original', 'Reconstructed')

figure;
plot(x,yr-y,'b');
title('Error Reconstructed - Original')
xlabel('x')
ylabel('e = yr - y')
legend('Error')

figure
plot(x,dy,'b');
hold on
plot(xr,dyr,'k.');
title('Original signal vs reconstructed signal derivative')
xlabel('x')
ylabel('dy = df/dx(x)')
legend('Original', 'Reconstructed')

%Compute mean squared error
MSE = mean((y-yr).^2)
