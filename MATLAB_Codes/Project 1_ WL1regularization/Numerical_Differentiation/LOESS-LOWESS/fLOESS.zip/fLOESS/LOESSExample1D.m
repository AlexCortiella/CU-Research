clc;
close all;
clear all;


%% 1D Example

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Set up parameters
%Noise (zero-mean AWGN)
sigma = 0.05;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


x0 = 0;
xf = 10;
dx = 0.01;
Nsamp = 300;
dxn = (xf-x0)/(Nsamp-1);
% p1 = -0.1;
% p2 = 1;
% funy = @(x) (exp(p1.*x).*cos(p2*x));
% fundy = @(x) (exp(p1.*x).*(p1*cos(p2*x) - p2*sin(p2*x)));
funy = @(x) (sin(x));
fundy = @(x) (cos(x));

x = (x0:dx:xf)';
xn = (x0:dxn:xf)';
rng(1);
y = funy(x);
dy = fundy(x);
yn = funy(xn);
ynoisy = yn + sigma*randn(Nsamp,1);

figure
plot(x,y,'b');
hold on
plot(xn,ynoisy,'k.');
title('Original signal vs Noisy signal')
xlabel('x')
ylabel('y = f(x)')
legend('Original', 'Noisy')

[yr, dyr] = LOESS_GCV(xn,ynoisy);

figure;
plot(xn,ynoisy,'k.');
hold on
plot(x,y,'b');
plot(xn,yr,'r');
title('Reconstructed signal vs original signal')
xlabel('x')
ylabel('y = f(x)')
legend('Noisy','Original', 'Reconstructed')

figure
plot(x,dy,'b');
hold on
plot(xn,dyr,'k.');
title('Original signal vs reconstructed signal derivative')
xlabel('x')
ylabel('dy = df/dx(x)')
legend('Original', 'Reconstructed')
% 
% %Compute mean squared error
% MSE = mean((y-yr).^2)
