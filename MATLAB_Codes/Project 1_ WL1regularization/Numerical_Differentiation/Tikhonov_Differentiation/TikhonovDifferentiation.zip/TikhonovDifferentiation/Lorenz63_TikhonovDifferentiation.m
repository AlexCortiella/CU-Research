%% Solve 1 dof linear/quadratic undamped, unforced, oscillator problem
clc;
close all;
clear all;
addpath('./regtools')
rng(100);

%% Dynamical system parameters
%System parameters
sigma = 10;
rho = 28;
beta = 8/3;
param = [sigma,rho,beta];
n = 3; %# state variables;

%Time parameters
dt = 0.0001;
t0 = 0;
tf = 5;

%Intial conditions
x0 = [-8;7;27];

tspanf = t0:dt:tf;

%% Sensor parameters
% Additive White Gaussian Noise to data;
etax = 0.01; %Noise level on the states
etadx = 0.01;%Noise level on the derivatives
sampleTime = 0.01; %Sampling time

%State sapace model of a 2nd order linear differential equation
options = odeset('RelTol',1e-10,'AbsTol',1e-10*ones(1,n));
[xf] = ode5(@(t,x) LorentzSys63(t,x,param),tspanf,x0');
x = xf;
t = tspanf';

%% Sample dynamical system
dsample = sampleTime/dt;
timeData = t(1:dsample:end);
Nsamples = length(timeData);


%% True state variables
x1true = x(1:dsample:end,1);
x2true = x(1:dsample:end,2);
x3true = x(1:dsample:end,3);
xDataT = [x1true,x2true,x3true];

%% True state derivatives
dx1true = sigma*(x2true-x1true);
dx2true = x1true.*(rho - x3true) - x2true;
dx3true = x1true.*x2true - beta*x3true;
dxDataT = [dx1true,dx2true,dx3true];

% X1 state
x1noisy = x1true.*(1+etax*randn(Nsamples,1));
% x1noisy = x1true + etax*randn(Nsamples,1);
% X2 state
x2noisy = x2true.*(1+etax*randn(Nsamples,1));
% x2noisy = x2true + etax*randn(Nsamples,1);
% X3 state
% x3noisy = x3true.*(1+etax*randn(Nsamples,1));
x3noisy = x3true + etax*randn(Nsamples,1);
xDataN = [x1noisy,x2noisy,x3noisy];

% dX1 state
dx1noisy = dx1true.*(1+etadx*randn(Nsamples,1));
% dx1noisy = dx1true + etadx*randn(Nsamples,1);
% dX2 state
% dx2noisy = dx2true.*(1+etadx*randn(Nsamples,1));
dx2noisy = dx2true + etadx*randn(Nsamples,1);
% dX3 state
% dx3noisy = dx3true.*(1+etadx*randn(Nsamples,1));
dx3noisy = dx3true + etadx*randn(Nsamples,1);

dxDataN = [dx1noisy,dx2noisy,dx3noisy];

%% Numerical computation of derivatives

%%  TIKHONOV REGULARIZATION
        
    %Vector of ordinates
    tvec = timeData;
    tvecm = 0.5*(tvec(1:end-1) + tvec(2:end));

    %Generate integral and regularization matrices ( C(x) = |Ax - y| + l*|Lx|)
    Nint = length(tvec)-1;%Number of grid partitions
    
    %Compute A and L matrices for GCV
    [dx,t,A,L,res,relres] = tik_diff(tvec,[],Nint,0);
    cond(A)
    %Variables to perform cross validation on l
    [U,sm,X,V,W] = cgsvd(A,L);
    
    for d = 1:n
        b = xDataN(:,d);
        [reg_min,G,reg_param] = gcv(U,sm,b,'Tikh');
        %reg_min = 0 %No regularization parameter
        [dx,t,A,L,res,relres] = tik_diff(tvec,b,Nint,reg_min);
        tdx = 0.5*(t(1:end-1) + t(2:end)); %Derivatives computed at the midpoints of t
        dxDataN(:,d) = pchip(tdx,dx,tvec);%Interpolation to the grid points
        pause
    end

%% PLOTS

figure(1);
subplot(3,1,1);
plot(timeData, xDataN(:,1),'r.')
hold on
plot(timeData, xDataT(:,1),'k')
xlabel('Time')
ylabel('x(t)')
legend('Noisy','True')

subplot(3,1,2);
plot(timeData, xDataN(:,2),'r.')
hold on
plot(timeData, xDataT(:,2),'k')
xlabel('Time')
ylabel('y(t)')
legend('Noisy','True')

subplot(3,1,3);
plot(timeData, xDataN(:,3),'r.')
hold on
plot(timeData, xDataT(:,3),'k')
xlabel('Time')
ylabel('z(t)')
legend('Noisy','True')

figure(2);
subplot(3,1,1);
plot(timeData, dxDataT(:,1),'k')
hold on
plot(timeData, dxDataN(:,1),'r.')
xlabel('Time')
ylabel('dx/dt(t)')
legend('Noisy','True')

subplot(3,1,2);
plot(timeData, dxDataT(:,2),'k')
hold on
plot(timeData, dxDataN(:,2),'r.')
xlabel('Time')
ylabel('dy/dt(t)')
legend('Noisy','True')

subplot(3,1,3);
plot(timeData, dxDataT(:,3),'k')
hold on
plot(timeData, dxDataN(:,3),'r.')
xlabel('Time')
ylabel('dz/dt(t)')
legend('Noisy','True')

samptrim = floor(0.1*Nsamples/2);
xDataN = xDataN(samptrim+1:end-samptrim,:);
dxDataN = dxDataN(samptrim+1:end-samptrim,:);
xDataT = xDataT(samptrim+1:end-samptrim,:);
dxDataT = dxDataT(samptrim+1:end-samptrim,:);
tData = timeData(samptrim+1:end-samptrim);

figure(3);
suptitle('Trimmed signal')
subplot(3,1,1);
plot(tData, dxDataT(:,1),'k')
hold on
plot(tData, dxDataN(:,1),'r.')
xlabel('Time')
ylabel('dx/dt(t)')
legend('Noisy','True')

subplot(3,1,2);
plot(tData, dxDataT(:,2),'k')
hold on
plot(tData, dxDataN(:,2),'r.')
xlabel('Time')
ylabel('dx/dt(t)')
legend('Noisy','True')

subplot(3,1,3);
plot(tData, dxDataT(:,3),'k')
hold on
plot(tData, dxDataN(:,3),'r.')
xlabel('Time')
ylabel('dx/dt(t)')
legend('Noisy','True')

%% Error analysis
mse = zeros(1,n);
mean_error = zeros(1,n);
std_error = zeros(1,n);
var_error = zeros(1,n);
relerror = zeros(1,n);

figure(4)
for d = 1:n
    error = dxDataT(:,d)-dxDataN(:,d);
    mse(d) = immse(dxDataT(:,d),dxDataN(:,d));
    mean_error(d) = mean(error);
    std_error(d) = std(error);
    var_error(d) = var(error);
    relerror(d) = norm(dxDataT(:,1)-dxDataN(:,1))/norm(dxDataT(:,1));
    subplot(3,1,d);
    histogram(error,20)
end


save('DataLorentz63Diff.mat','xDataT','dxDataT','xDataN','dxDataN','tData')